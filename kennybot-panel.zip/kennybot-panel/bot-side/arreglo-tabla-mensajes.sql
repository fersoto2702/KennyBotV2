-- ─────────────────────────────────────────────────────────────
--  Arreglo de la tabla `mensajes`
--
--  Tu registerMessage usa  INSERT ... ON DUPLICATE KEY UPDATE,
--  pero la tabla no tiene ninguna clave ÚNICA sobre
--  (grupo, usuario, fecha). Sin ella, MySQL nunca detecta el
--  "duplicado" e inserta una fila nueva por cada mensaje, en vez
--  de sumar a la fila del día. Los totales salen bien (por el SUM),
--  pero la tabla crece sin parar y las consultas se vuelven lentas.
--
--  Esto junta las filas repetidas y agrega la clave única.
--  Haz antes un respaldo:   mysqldump -u root -p kennybotdb mensajes > respaldo.sql
-- ─────────────────────────────────────────────────────────────

CREATE TABLE mensajes_nueva LIKE mensajes;

ALTER TABLE mensajes_nueva
    ADD UNIQUE KEY uq_grupo_usuario_fecha (grupo, usuario, fecha);

INSERT INTO mensajes_nueva (grupo, usuario, cantidad, fecha, ultimo_mensaje)
SELECT
    grupo,
    usuario,
    SUM(cantidad),
    fecha,
    MAX(ultimo_mensaje)
FROM mensajes
GROUP BY grupo, usuario, fecha;

RENAME TABLE
    mensajes TO mensajes_vieja,
    mensajes_nueva TO mensajes;

-- Cuando confirmes que todo funciona:
-- DROP TABLE mensajes_vieja;
