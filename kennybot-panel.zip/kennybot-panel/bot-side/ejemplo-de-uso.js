/*
 * Cómo conectar el panel a tu bot (por ejemplo en index.js,
 * después de initDB() y de crear el socket).
 *
 * 1. Copia panel-api.js a la carpeta  utils/  de KennyBotV2.
 *
 * 2. Genera un token largo (solo una vez) y guárdalo en tu .env:
 *
 *        node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
 *
 *        PANEL_TOKEN=el-token-que-salio
 *        PANEL_ORIGIN=https://tu-web.com
 *
 * 3. Arráncalo así:
 */

const path = require('path')

const startPanelApi = require('./utils/panel-api')
const { pool } = require('./database/mysql')


startPanelApi({

    pool,

    token: process.env.PANEL_TOKEN,

    // Solo esta web podrá usar la API desde un navegador.
    origin: process.env.PANEL_ORIGIN,

    // Para mostrar los nombres reales de tus grupos. Ajusta a como se llame tu socket.
    getSock: () => sock,

    // Lee la carpeta de comandos y los agrupa solo.
    commandsDir: path.join(__dirname, 'comandos'),

    // Puerto y host (por defecto 4000 en 127.0.0.1, solo local).
    // port: 4000,

    hooks: {

        // Todos son opcionales. Si falta uno, esa acción responde
        // "no disponible" y el panel lo muestra como un error claro.

        // reload: async () => reloadAll(),   // de src/utils/reloadCommands.js
        // restart: async () => { process.exit(0) },   // tu gestor (pm2, nodemon) lo vuelve a levantar

        // isCommandEnabled: (name) => true,               // lee tu toggle system
        // setCommand: async (name, enabled) => { },       // escribe tu toggle system

        // Switches por grupo (usa tu toggles.js). El panel envía { features: { antibot: true } }.
        // groupSettings: (jid) => ({ features: { antibot: isEnabled(jid, 'antibot') } }),
        // setGroup: async (jid, patch) => { for (const [k, v] of Object.entries(patch.features || {})) setToggle(jid, k, v) },

        // userName: (jid) => 'Nombre',
        // userStats: (jid) => ({ level: 3, xp: 120, coins: 500 }),

        // warns: async () => [{ id, user, group, reason, count, max }],
        // addWarn: async (user, group, reason) => { },
        // removeWarn: async (id) => { },

        // queueSize: () => 0,
        // moduleCount: () => 96

    }

})
