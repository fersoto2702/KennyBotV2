# KennyBot · Panel

Panel de control para KennyBot. React + Vite + Tailwind + framer-motion + lucide-react.
Estilo: vidrio líquido oscuro con acento verde (inspirado en "Glassy Dashboard V31").


## Arrancar

    npm install
    npm run dev        # desarrollo en http://localhost:5173
    npm run build      # genera la carpeta dist/ para subir a tu web


## Subirlo a tu página

`npm run build` crea `dist/`. Sube esa carpeta a tu hosting (usa rutas relativas,
funciona en cualquier subcarpeta). Las rutas usan # (hash), no necesita configurar el servidor.


## Conectarlo a tu bot

1. En el panel: Ajustes → Conexión → pon la URL de tu API.
   También puedes crear un archivo .env con:  VITE_API_URL=https://tu-bot.com/api

2. Tu servidor (Node/Baileys) debe responder, con CORS habilitado:

        GET  /stats                 → { bot, ranges, groups, commands, leaderboard, warns, types }
        POST /reload                → recarga los módulos
        POST /restart               → reinicia el bot
        POST /commands/:nombre      → { enabled: true | false }
        POST /commands              → { name, category }
        POST /groups/:id            → { status?, welcome?, antilink? }
        POST /warns                 → { user, group, reason }
        POST /warns/:id/remove      → quita un warn

   La forma de cada clave de /stats está en  src/data/demo.js
   (status de grupo: 'active' | 'watch' | 'muted').


## Dónde cambiar cosas

    src/data/demo.js        datos de ejemplo (reemplázalos o conecta la API)
    src/lib/api.js          cliente de la API
    src/state.jsx           estado global y acciones
    src/pages/Plans.jsx     precios y beneficios (lista PLANS)
    src/index.css           sistema de vidrio (.glass, .btn, .sw …)
    tailwind.config.js      colores, fuentes, animaciones


## Fondo con foto

Ajustes → Apariencia → Imagen de fondo: pega la URL de una imagen para el efecto
de refracción sobre una foto, como en el video de referencia.


## Conectar con KennyBotV2 (carpeta bot-side/)

    bot-side/panel-api.js            la API (sin dependencias, solo http de Node)
    bot-side/ejemplo-de-uso.js       cómo arrancarla desde tu index.js
    bot-side/arreglo-tabla-mensajes.sql   arregla la tabla `mensajes` (ver abajo)

1. Copia panel-api.js a la carpeta utils/ de tu bot.
2. Genera un token y ponlo en tu .env como PANEL_TOKEN (nunca en el código):

        node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

3. Arráncala como en ejemplo-de-uso.js (usa el pool de tu database/mysql.js).
4. En el panel: Ajustes → Conexión → pega la URL de la API y el mismo token.

Datos reales desde la tabla `mensajes`: gráfica de 7 y 30 días, grupos y ranking
por mensajes. Los comandos salen de leer tu carpeta /comandos. Lo que tu tabla
no guarda (gráfica de 24 h, mapa de actividad, usos por comando, XP, monedas,
warns) no se inventa: esas secciones se ocultan hasta que agregues el hook
correspondiente en startPanelApi.

Aviso sobre `mensajes`: registerMessage usa ON DUPLICATE KEY UPDATE, pero la
tabla no tiene clave única, así que cada mensaje crea una fila nueva. Los
totales salen bien, pero la tabla crece sin parar. arreglo-tabla-mensajes.sql
junta las filas repetidas y agrega la clave. Haz respaldo antes.
