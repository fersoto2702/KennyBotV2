/** @type {import('tailwindcss').Config} */
export default {

    content: [ './index.html', './src/**/*.{js,jsx}' ],

    theme: {

        extend: {

            colors: {

                night: {

                    950: '#050d0a',
                    900: '#08140f',
                    800: '#0d1f17',

                },

                kb: {

                    DEFAULT: 'rgb(var(--acc) / <alpha-value>)',
                    gold: '#d4a73c',
                    cyan: '#4fd8e6',
                    coral: '#ff6b4a',

                },

            },

            fontFamily: {

                display: [ '"Bricolage Grotesque"', 'Geist', 'system-ui', 'sans-serif' ],
                sans: [ 'Geist', 'system-ui', '-apple-system', 'sans-serif' ],
                mono: [ '"Geist Mono"', 'ui-monospace', 'monospace' ],

            },

            borderRadius: {

                glass: '26px',

            },

            keyframes: {

                drift1: { to: { transform: 'translate(14vw, -8vh) scale(1.15)' } },
                drift2: { to: { transform: 'translate(-16vw, -10vh) scale(.9)' } },
                drift3: { to: { transform: 'translate(-12vw, 16vh) scale(1.2)' } },
                ping2: { '70%': { boxShadow: '0 0 0 9px rgba(77,255,176,0)' }, '100%': { boxShadow: '0 0 0 0 rgba(77,255,176,0)' } },
                shine: { to: { transform: 'translateX(220%)' } },

            },

            animation: {

                drift1: 'drift1 26s ease-in-out infinite alternate',
                drift2: 'drift2 32s ease-in-out infinite alternate',
                drift3: 'drift3 38s ease-in-out infinite alternate',
                ping2: 'ping2 2s infinite',
                shine: 'shine 2.4s ease-in-out infinite',

            },

        },

    },

    plugins: [],

}
