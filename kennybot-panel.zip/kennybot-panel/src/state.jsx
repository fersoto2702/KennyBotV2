import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'

import { DEMO } from './data/demo'
import { api } from './lib/api'
import { store } from './lib/format'


const Ctx = createContext( null )


export const useApp = () => useContext( Ctx )


/*
    Con la API conectada solo se muestra lo que tu bot envía.
    Lo que no envía queda vacío, en lugar de mezclarse con los datos de ejemplo.
*/

const LIVE_BASE = {

    ...DEMO,

    ranges: {},
    groups: [],
    commands: [],
    leaderboard: [],
    warns: [],

}


export const ACCENTS = [

    [ 'Esmeralda', '47 191 138' ],
    [ 'Dorado', '212 167 60' ],
    [ 'Turquesa', '39 181 201' ],
    [ 'Lima', '155 209 63' ],
    [ 'Coral', '239 125 95' ],

]


export function useHashRoute() {

    const read = () => window.location.hash.replace( '#/', '' ) || 'overview'

    const [ route, setRoute ] = useState( read )

    useEffect( () => {

        const on = () => {

            setRoute( read() )

            window.scrollTo( { top: 0 } )

        }

        window.addEventListener( 'hashchange', on )

        return () => window.removeEventListener( 'hashchange', on )

    }, [] )

    return route

}


export function AppProvider( { children } ) {

    const [ data, setData ] = useState( DEMO )

    const [ toasts, setToasts ] = useState( [] )

    const [ apiBase, setApiBase ] = useState( api.base )

    const [ accent, setAccentState ] = useState( store( 'kb.acc' ) || ACCENTS[ 0 ][ 1 ] )

    const [ palette, setPalette ] = useState( false )

    const [ navOpen, setNavOpen ] = useState( false )

    const [ bg, setBgState ] = useState( store( 'kb.bg' ) || '' )


    useEffect( () => {

        document.documentElement.style.setProperty( '--acc', accent )

        store( 'kb.acc', accent )

    }, [ accent ] )


    useEffect( () => {

        store( 'kb.bg', bg )

    }, [ bg ] )


    const toast = useCallback( ( text, kind = 'ok' ) => {

        const id = Math.random().toString( 36 ).slice( 2 )

        setToasts( ( t ) => [ ...t, { id, text, kind } ] )

        setTimeout( () => setToasts( ( t ) => t.filter( ( x ) => x.id !== id ) ), 3600 )

    }, [] )


    const loadStats = useCallback( async () => {

        const json = await api.call( '/stats' )

        setData( ( prev ) => ( {

            ...LIVE_BASE,

            ...json,

            bot: { ...DEMO.bot, ...json.bot, uptimeSec: json.bot?.uptimeSec ?? prev.bot.uptimeSec },

        } ) )

    }, [] )


    useEffect( () => {

        if ( api.base ) {

            loadStats().catch( () => toast( 'No se pudo leer tu API. Se muestran datos de ejemplo.', 'err' ) )

        }

    }, [ loadStats, toast ] )


    useEffect( () => {

        const id = setInterval( () => {

            setData( ( d ) => ( { ...d, bot: { ...d.bot, uptimeSec: d.bot.uptimeSec + 1 } } ) )

        }, 1000 )

        return () => clearInterval( id )

    }, [] )


    useEffect( () => {

        const on = ( e ) => {

            if ( ( e.ctrlKey || e.metaKey ) && e.key.toLowerCase() === 'k' ) {

                e.preventDefault()

                setPalette( ( p ) => ! p )

            }

        }

        window.addEventListener( 'keydown', on )

        return () => window.removeEventListener( 'keydown', on )

    }, [] )


    const actions = useMemo( () => ( {

        async run( path, method, body, okText ) {

            try {

                const res = await api.call( path, method, body )

                if ( okText ) {

                    toast( typeof okText === 'function' ? okText( res ) : okText )

                }

                return res || true

            } catch ( err ) {

                toast( 'No se pudo completar la acción. ' + err.message, 'err' )

                return false

            }

        },

    } ), [ toast ] )


    const toggleCommand = async ( name ) => {

        const cmd = data.commands.find( ( c ) => c.name === name )

        const next = ! cmd.on

        setData( ( d ) => ( { ...d, commands: d.commands.map( ( c ) => c.name === name ? { ...c, on: next } : c ) } ) )

        const ok = await actions.run( '/commands/' + name, 'POST', { enabled: next }, `.${ name } ${ next ? 'activado' : 'desactivado' }` )

        if ( ! ok ) {

            setData( ( d ) => ( { ...d, commands: d.commands.map( ( c ) => c.name === name ? { ...c, on: ! next } : c ) } ) )

        }

    }


    const addCommand = async ( name, cat ) => {

        const clean = name.trim().replace( /^[.!/]/, '' ).toLowerCase()

        if ( ! clean ) {

            toast( 'Escribe un nombre para el comando.', 'err' )

            return false

        }

        if ( data.commands.some( ( c ) => c.name === clean ) ) {

            toast( `Ya existe el comando .${ clean }. Elige otro nombre.`, 'err' )

            return false

        }

        const ok = await actions.run( '/commands', 'POST', { name: clean, category: cat }, `Comando .${ clean } creado` )

        if ( ok ) {

            setData( ( d ) => ( { ...d, commands: [ { name: clean, cat, uses: 0, on: true }, ...d.commands ] } ) )

        }

        return ok

    }


    const updateGroup = async ( id, patch ) => {

        const prev = data.groups.find( ( g ) => g.id === id )

        const merge = ( g ) => ( {

            ...g,
            ...patch,

            features: { ...( g.features || {} ), ...( patch.features || {} ) },

        } )

        setData( ( d ) => ( { ...d, groups: d.groups.map( ( g ) => g.id === id ? merge( g ) : g ) } ) )

        const ok = await actions.run( '/groups/' + id, 'POST', patch )

        if ( ! ok ) {

            setData( ( d ) => ( { ...d, groups: d.groups.map( ( g ) => g.id === id ? prev : g ) } ) )

        }

        return ok

    }


    const removeWarn = async ( id ) => {

        const w = data.warns.find( ( x ) => x.id === id )

        const ok = await actions.run( `/warns/${ id }/remove`, 'POST', undefined, `Warn de ${ w.user } eliminado` )

        if ( ok ) {

            setData( ( d ) => ( { ...d, warns: d.warns.filter( ( x ) => x.id !== id ) } ) )

        }

    }


    const addWarn = async ( user, group, reason ) => {

        if ( ! user.trim() ) {

            toast( 'Escribe el nombre del usuario.', 'err' )

            return false

        }

        const ok = await actions.run( '/warns', 'POST', { user, group, reason }, `Warn agregado a ${ user }` )

        if ( ok ) {

            setData( ( d ) => ( { ...d, warns: [ { id: Date.now(), user: user.trim(), group, reason: reason || 'Sin motivo', count: 1, max: 3 }, ...d.warns ] } ) )

        }

        return ok

    }


    const connect = async ( url, token ) => {

        api.setBase( url )
        api.setToken( token )

        setApiBase( url )

        try {

            await loadStats()

            toast( 'Conectado. Los datos ahora vienen de tu bot.' )

        } catch ( err ) {

            api.setBase( '' )

            setApiBase( '' )

            setData( DEMO )

            toast( 'No se pudo conectar. ' + err.message + ' (revisa también que la URL sea https y que tu API permita CORS)', 'err' )

        }

    }


    const disconnect = () => {

        api.setBase( '' )
        api.setToken( '' )

        setApiBase( '' )

        setData( DEMO )

        toast( 'Mostrando datos de ejemplo' )

    }


    const value = {

        data,
        toasts,
        toast,
        apiBase,
        accent,
        setAccent: setAccentState,
        palette,
        setPalette,
        navOpen,
        setNavOpen,
        bg,
        setBg: setBgState,
        run: actions.run,
        toggleCommand,
        addCommand,
        updateGroup,
        removeWarn,
        addWarn,
        connect,
        disconnect,

    }

    return <Ctx.Provider value={ value }>{ children }</Ctx.Provider>

}
