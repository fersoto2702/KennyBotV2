import { useEffect, useState } from 'react'
import { animate } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'

import { Glass } from './Glass'
import { Sparkline } from './Charts'
import { fmt } from '../lib/format'
import { makeSeries } from '../data/demo'


export function CountUp( { to, pre = '', suf = '' } ) {

    const [ v, setV ] = useState( 0 )

    useEffect( () => {

        const c = animate( 0, to, {

            duration: 1.3,
            ease: [ .2, .8, .2, 1 ],

            onUpdate: setV,

        } )

        return () => c.stop()

    }, [ to ] )

    return <>{ pre }{ fmt( v ) }{ suf }</>

}


export function StatCard( { i, icon: Icon, label, value, delta, note, seed, pre, suf, plain = false, className = 'col-span-12 sm:col-span-6 xl:col-span-3' } ) {

    const down = delta < 0

    return (

        <Glass
            i={ i }
            hover
            className={ `p-[22px] ${ className }` }
        >

            <div className="flex items-center justify-between font-medium text-white/65">

                { label }

                <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-kb/20 text-kb">

                    <Icon size={ 17 } />

                </span>

            </div>

            <div className="mt-2.5 font-display text-[36px] font-extrabold leading-none tracking-[-0.04em] tabular-nums text-white">

                <CountUp
                    to={ value }
                    pre={ pre }
                    suf={ suf }
                />

            </div>

            <div className="mt-3 flex items-center justify-between text-[12.5px] text-white/45">

                { ! plain && <span className={ `inline-flex items-center gap-1 rounded-full px-[9px] py-0.5 font-semibold ${ down ? 'bg-[#ff6b4a]/20 text-[#ff9b84]' : 'bg-kb/20 text-[#7ff0bf]' }` }>

                    <ArrowUpRight
                        size={ 11 }
                        className={ down ? 'rotate-90' : '' }
                    />

                    { Math.abs( delta ) }%

                </span> }

                <span>{ note }</span>

            </div>

            { ! plain && (

                <Sparkline
                    data={ makeSeries( 14, 40, 60, seed ) }
                    color={ down ? '#ff6b4a' : 'rgb(var(--acc))' }
                />

            ) }

        </Glass>

    )

}
