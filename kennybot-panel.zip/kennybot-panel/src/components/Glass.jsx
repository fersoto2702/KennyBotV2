import { motion } from 'framer-motion'


export const rise = {

    hidden: { opacity: 0, y: 18, scale: .985, filter: 'blur(10px)' },

    show: ( i = 0 ) => ( {

        opacity: 1,
        y: 0,
        scale: 1,
        filter: 'blur(0px)',

        transition: { duration: .75, delay: i * .06, ease: [ .2, .8, .2, 1 ] },

    } ),

}


function follow( e ) {

    const box = e.currentTarget.getBoundingClientRect()

    e.currentTarget.style.setProperty( '--mx', ( e.clientX - box.left ) + 'px' )
    e.currentTarget.style.setProperty( '--my', ( e.clientY - box.top ) + 'px' )

}


export function Glass( { i = 0, className = '', deep = false, children, hover = false, ...rest } ) {

    return (

        <motion.section
            variants={ rise }
            initial="hidden"
            animate="show"
            custom={ i }
            whileHover={ hover ? { y: -4 } : undefined }
            onPointerMove={ follow }
            className={ `glass ${ deep ? 'glass-deep' : '' } ${ className }` }
            { ...rest }
        >

            { children }

        </motion.section>

    )

}


export function CardHead( { title, sub, children } ) {

    return (

        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">

            <div>

                <h3 className="font-display text-lg font-bold tracking-tight text-white">

                    { title }

                </h3>

                { sub && <p className="mt-0.5 text-[13px] text-white/50">{ sub }</p> }

            </div>

            { children }

        </div>

    )

}


export function PageHead( { title, sub, children } ) {

    return (

        <motion.div
            variants={ rise }
            initial="hidden"
            animate="show"
            custom={ 0 }
            className="mx-1 mb-6 mt-2 flex flex-wrap items-end justify-between gap-4"
        >

            <div>

                <h1 className="font-display text-[clamp(30px,4.2vw,46px)] font-extrabold leading-[1.02] tracking-[-0.035em] text-white">

                    { title }

                </h1>

                <p className="mt-2 max-w-[58ch] text-white/65">{ sub }</p>

            </div>

            <div className="flex flex-wrap items-center gap-2.5">{ children }</div>

        </motion.div>

    )

}


export function SampleNote( { children } ) {

    return (

        <motion.div
            variants={ rise }
            initial="hidden"
            animate="show"
            custom={ 1 }
            role="note"
            className="mb-4 flex items-start gap-3 rounded-2xl bg-kb-gold/15 px-4 py-3 text-[13.5px] text-[#f0cf7a]"
        >

            <span className="mt-0.5 h-2 w-2 flex-none rounded-full bg-kb-gold" />

            <span>{ children }</span>

        </motion.div>

    )

}


export function Seg( { value, onChange, options } ) {

    return (

        <div className="inline-flex rounded-full bg-black/30 p-[3px]">

            { options.map( ( [ v, label ] ) => (

                <button
                    key={ v }
                    aria-pressed={ value === v }
                    onClick={ () => onChange( v ) }
                    className={ `h-7 whitespace-nowrap rounded-full px-3.5 text-[13px] font-medium transition ${ value === v ? 'bg-white text-night-950' : 'text-white/65 hover:text-white' }` }
                >

                    { label }

                </button>

            ) ) }

        </div>

    )

}


export function Toggle( { on, onChange, label } ) {

    return (

        <button
            role="switch"
            aria-checked={ on }
            aria-label={ label }
            onClick={ onChange }
            className="sw"
        />

    )

}


export function Bar( { pct, delay = 0 } ) {

    return (

        <div className="bar">

            <motion.i
                initial={ { width: 0 } }
                animate={ { width: pct + '%' } }
                transition={ { duration: 1.2, delay: .3 + delay, ease: [ .2, .8, .2, 1 ] } }
            />

        </div>

    )

}
