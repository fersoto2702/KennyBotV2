import { useEffect, useId, useRef, useState } from 'react'
import { animate, motion } from 'framer-motion'

import { clamp, fmt, rng } from '../lib/format'


function niceMax( v ) {

    const pow = 10 ** Math.floor( Math.log10( v ) )

    const n = v / pow

    return ( n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10 ) * pow

}


export function smoothPath( pts ) {

    let d = `M${ pts[ 0 ][ 0 ] } ${ pts[ 0 ][ 1 ] }`

    for ( let i = 0; i < pts.length - 1; i++ ) {

        const p0 = pts[ i - 1 ] || pts[ i ]
        const p1 = pts[ i ]
        const p2 = pts[ i + 1 ]
        const p3 = pts[ i + 2 ] || p2

        const c1x = p1[ 0 ] + ( p2[ 0 ] - p0[ 0 ] ) / 6
        const c1y = p1[ 1 ] + ( p2[ 1 ] - p0[ 1 ] ) / 6
        const c2x = p2[ 0 ] - ( p3[ 0 ] - p1[ 0 ] ) / 6
        const c2y = p2[ 1 ] - ( p3[ 1 ] - p1[ 1 ] ) / 6

        d += ` C${ c1x.toFixed( 1 ) } ${ c1y.toFixed( 1 ) } ${ c2x.toFixed( 1 ) } ${ c2y.toFixed( 1 ) } ${ p2[ 0 ].toFixed( 1 ) } ${ p2[ 1 ].toFixed( 1 ) }`

    }

    return d

}


export function AreaChart( { labels, series } ) {

    const uid = useId().replace( /:/g, '' )

    const ref = useRef( null )

    const [ hover, setHover ] = useState( null )

    const W = 820
    const H = 300

    const pl = 46
    const pr = 14
    const pt = 14
    const pb = 30

    const max = niceMax( Math.max( ...series.flatMap( ( s ) => s.data ) ) * 1.05 )

    const x = ( i ) => pl + ( W - pl - pr ) * i / ( labels.length - 1 )

    const y = ( v ) => pt + ( H - pt - pb ) * ( 1 - v / max )

    const step = Math.ceil( labels.length / 8 )


    function move( e ) {

        const box = ref.current.getBoundingClientRect()

        const rel = ( e.clientX - box.left ) / box.width * W

        setHover( clamp( Math.round( ( rel - pl ) / ( W - pl - pr ) * ( labels.length - 1 ) ), 0, labels.length - 1 ) )

    }


    return (

        <div
            ref={ ref }
            className="relative"
        >

            <svg
                viewBox={ `0 0 ${ W } ${ H }` }
                className="block h-auto w-full overflow-visible"
                role="img"
                aria-label="Gráfica de actividad"
            >

                <defs>

                    { series.map( ( s, k ) => (

                        <linearGradient
                            key={ k }
                            id={ `ag${ uid }${ k }` }
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                        >

                            <stop offset="0" stopColor={ s.color } stopOpacity=".42" />
                            <stop offset="1" stopColor={ s.color } stopOpacity="0" />

                        </linearGradient>

                    ) ) }

                </defs>

                { [ 0, 1, 2, 3, 4 ].map( ( g ) => {

                    const v = max * g / 4

                    return (

                        <g key={ g }>

                            <line
                                x1={ pl }
                                x2={ W - pr }
                                y1={ y( v ) }
                                y2={ y( v ) }
                                stroke="rgba(255,255,255,.09)"
                                strokeDasharray={ g ? '3 5' : undefined }
                            />

                            <text
                                x={ pl - 10 }
                                y={ y( v ) + 4 }
                                textAnchor="end"
                                className="fill-white/40 text-[11.5px]"
                            >

                                { v >= 1000 ? ( v / 1000 ) + 'k' : v }

                            </text>

                        </g>

                    )

                } ) }

                { labels.map( ( l, i ) => i % step === 0 && (

                    <text
                        key={ i }
                        x={ x( i ) }
                        y={ H - 8 }
                        textAnchor="middle"
                        className="fill-white/40 text-[11.5px]"
                    >

                        { l }

                    </text>

                ) ) }

                { series.map( ( s, k ) => {

                    const pts = s.data.map( ( v, i ) => [ x( i ), y( v ) ] )

                    const line = smoothPath( pts )

                    return (

                        <g key={ s.name + labels.length }>

                            <motion.path
                                d={ `${ line } L${ x( labels.length - 1 ) } ${ y( 0 ) } L${ x( 0 ) } ${ y( 0 ) }Z` }
                                fill={ `url(#ag${ uid }${ k })` }
                                initial={ { opacity: 0 } }
                                animate={ { opacity: 1 } }
                                transition={ { delay: .6, duration: 1 } }
                            />

                            <motion.path
                                d={ line }
                                fill="none"
                                stroke={ s.color }
                                strokeWidth="2.6"
                                strokeLinecap="round"
                                initial={ { pathLength: 0 } }
                                animate={ { pathLength: 1 } }
                                transition={ { duration: 1.4, delay: .2, ease: [ .3, .7, .2, 1 ] } }
                            />

                        </g>

                    )

                } ) }

                { hover !== null && (

                    <g>

                        <line
                            x1={ x( hover ) }
                            x2={ x( hover ) }
                            y1={ pt }
                            y2={ H - pb }
                            stroke="rgba(255,255,255,.35)"
                            strokeDasharray="4 4"
                        />

                        { series.map( ( s, k ) => (

                            <circle
                                key={ k }
                                cx={ x( hover ) }
                                cy={ y( s.data[ hover ] ) }
                                r="5.5"
                                fill="#06130e"
                                stroke={ s.color }
                                strokeWidth="3"
                            />

                        ) ) }

                    </g>

                ) }

                <rect
                    x={ pl }
                    y="0"
                    width={ W - pl - pr }
                    height={ H }
                    fill="transparent"
                    onPointerMove={ move }
                    onPointerLeave={ () => setHover( null ) }
                />

            </svg>

            { hover !== null && (

                <div
                    className="pointer-events-none absolute z-10 min-w-[130px] -translate-x-1/2 -translate-y-[110%] rounded-xl bg-black/80 px-3 py-2 text-[12.5px] shadow-2xl backdrop-blur"
                    style={ {

                        left: clamp( x( hover ) / W * ( ref.current?.clientWidth || W ), 70, ( ref.current?.clientWidth || W ) - 70 ),
                        top: y( Math.max( ...series.map( ( s ) => s.data[ hover ] ) ) ) / H * ( ref.current?.clientHeight || H ),

                    } }
                >

                    <b className="mb-1 block font-display">{ labels[ hover ] }</b>

                    { series.map( ( s ) => (

                        <span
                            key={ s.name }
                            className="flex justify-between gap-3.5"
                        >

                            <span style={ { color: s.color } }>● { s.name }</span>

                            <b>{ fmt( s.data[ hover ] ) }</b>

                        </span>

                    ) ) }

                </div>

            ) }

        </div>

    )

}


export function Sparkline( { data, color = 'rgb(var(--acc))' } ) {

    const W = 200
    const H = 34

    const lo = Math.min( ...data )
    const hi = Math.max( ...data )

    const pts = data.map( ( v, i ) => [ i / ( data.length - 1 ) * W, H - 4 - ( v - lo ) / ( hi - lo || 1 ) * ( H - 8 ) ] )

    return (

        <svg
            viewBox={ `0 0 ${ W } ${ H }` }
            preserveAspectRatio="none"
            className="mt-2 block h-[34px] w-full"
            aria-hidden="true"
        >

            <motion.path
                d={ smoothPath( pts ) }
                fill="none"
                stroke={ color }
                strokeWidth="2"
                strokeLinecap="round"
                initial={ { pathLength: 0 } }
                animate={ { pathLength: 1 } }
                transition={ { duration: 1.2, delay: .3 } }
            />

        </svg>

    )

}


export function Gauge( { pct } ) {

    const len = Math.PI * 90

    const id = useId().replace( /:/g, '' )

    const [ angle, setAngle ] = useState( -90 )

    useEffect( () => {

        const c = animate( -90, pct / 100 * 180 - 90, {

            type: 'spring',
            stiffness: 40,
            damping: 9,
            delay: .2,

            onUpdate: setAngle,

        } )

        return () => c.stop()

    }, [ pct ] )

    return (

        <div className="mx-auto max-w-[300px]">

            <svg
                viewBox="0 0 220 135"
                aria-hidden="true"
            >

                <defs>

                    <linearGradient
                        id={ id }
                        x1="0"
                        x2="1"
                    >

                        <stop offset="0" stopColor="#d4a73c" />
                        <stop offset="1" stopColor="rgb(var(--acc))" />

                    </linearGradient>

                </defs>

                <path
                    d="M20 120 A90 90 0 0 1 200 120"
                    fill="none"
                    stroke="rgba(255,255,255,.12)"
                    strokeWidth="14"
                    strokeLinecap="round"
                />

                <motion.path
                    d="M20 120 A90 90 0 0 1 200 120"
                    fill="none"
                    stroke={ `url(#${ id })` }
                    strokeWidth="14"
                    strokeLinecap="round"
                    strokeDasharray={ len }
                    initial={ { strokeDashoffset: len } }
                    animate={ { strokeDashoffset: len * ( 1 - pct / 100 ) } }
                    transition={ { duration: 1.6, ease: [ .3, .9, .3, 1 ] } }
                />

                <g transform={ `rotate(${ angle } 110 120)` }>

                    <line
                        x1="110"
                        y1="120"
                        x2="110"
                        y2="44"
                        stroke="#fff"
                        strokeWidth="3.2"
                        strokeLinecap="round"
                    />

                </g>

                <circle cx="110" cy="120" r="8" fill="#fff" />
                <circle cx="110" cy="120" r="3" fill="#06130e" />

            </svg>

        </div>

    )

}


export function Donut( { items, colors, center } ) {

    const R = 54
    const C = 2 * Math.PI * R

    const total = items.reduce( ( a, b ) => a + b.value, 0 )

    let off = 0

    return (

        <svg
            viewBox="0 0 150 150"
            aria-hidden="true"
        >

            { items.map( ( it, i ) => {

                const seg = it.value / total * C

                const o = off

                off += seg

                return (

                    <motion.circle
                        key={ it.label }
                        r={ R }
                        cx="75"
                        cy="75"
                        fill="none"
                        stroke={ colors[ i ] }
                        strokeWidth="20"
                        strokeDasharray={ `${ Math.max( 0, seg - 3 ) } ${ C }` }
                        strokeDashoffset={ -o }
                        transform="rotate(-90 75 75)"
                        initial={ { opacity: 0 } }
                        animate={ { opacity: 1 } }
                        transition={ { delay: .2 + i * .12, duration: .8 } }
                    />

                )

            } ) }

            <text
                x="75"
                y="73"
                textAnchor="middle"
                className="fill-white font-display text-[24px] font-extrabold"
            >

                { center }

            </text>

            <text
                x="75"
                y="90"
                textAnchor="middle"
                className="fill-white/50 text-[11px]"
            >

                mensajes

            </text>

        </svg>

    )

}


export function Heatmap( { days } ) {

    const cells = []

    const r = rng( 77 )

    days.forEach( ( d, di ) => {

        const row = []

        for ( let h = 0; h < 24; h++ ) {

            const peak = Math.exp( -( ( h - 20 ) ** 2 ) / 22 ) + Math.exp( -( ( h - 13 ) ** 2 ) / 30 ) * .6

            row.push( clamp( peak * ( di > 4 ? 1 : .8 ) + r() * .22, .02, 1 ) )

        }

        cells.push( row )

    } )

    return (

        <div
            className="grid items-center gap-1"
            style={ { gridTemplateColumns: '34px repeat(24, minmax(0, 1fr))' } }
        >

            <span />

            { Array.from( { length: 24 }, ( _, h ) => (

                <span
                    key={ h }
                    className="text-[11.5px] text-white/40"
                >

                    { h % 3 === 0 ? h : '' }

                </span>

            ) ) }

            { days.map( ( d, di ) => (

                <div
                    key={ d }
                    className="contents"
                >

                    <span className="text-[11.5px] text-white/40">{ d }</span>

                    { cells[ di ].map( ( v, h ) => (

                        <motion.i
                            key={ h }
                            title={ `${ d } ${ h }:00` }
                            className="aspect-square rounded-md"
                            style={ { background: `color-mix(in srgb, rgb(var(--acc)) ${ Math.round( v * 100 ) }%, rgba(255,255,255,.06))` } }
                            initial={ { opacity: 0, scale: .6 } }
                            animate={ { opacity: 1, scale: 1 } }
                            whileHover={ { scale: 1.5, zIndex: 2 } }
                            transition={ { delay: ( di * 24 + h ) * .004 } }
                        />

                    ) ) }

                </div>

            ) ) }

        </div>

    )

}
