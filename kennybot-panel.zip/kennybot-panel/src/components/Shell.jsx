import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'

import {
    Bell,
    Bot,
    ChartLine,
    Check,
    CreditCard,
    LayoutDashboard,
    Menu,
    Search,
    ShieldCheck,
    SlidersHorizontal,
    Terminal,
    Trophy,
    Users,
    X,
} from 'lucide-react'

import { useApp } from '../state'
import { uptimeText } from '../lib/format'


export const NAV = [

    [ 'General', [

        { id: 'overview', label: 'Resumen', icon: LayoutDashboard },
        { id: 'analytics', label: 'Analíticas', icon: ChartLine },

    ] ],

    [ 'Bot', [

        { id: 'groups', label: 'Grupos', icon: Users, badge: ( d ) => d.groups.length },
        { id: 'commands', label: 'Comandos', icon: Terminal, badge: ( d ) => d.commands.length },
        { id: 'ranking', label: 'Ranking', icon: Trophy },

    ] ],

    [ 'Gestión', [

        { id: 'moderation', label: 'Moderación', icon: ShieldCheck, badge: ( d ) => d.warns.length },
        { id: 'plans', label: 'Planes', icon: CreditCard },
        { id: 'settings', label: 'Ajustes', icon: SlidersHorizontal },

    ] ],

]


export function Background() {

    const { bg } = useApp()

    return (

        <div
            className="scene"
            aria-hidden="true"
        >

            { bg && (

                <div
                    className="scene-photo"
                    style={ { backgroundImage: `url(${ bg })` } }
                />

            ) }

            <i className="absolute left-[-8vw] top-[10vh] h-[46vw] w-[46vw] animate-drift1 rounded-full bg-[#1d7a63] opacity-50 blur-[90px]" />
            <i className="absolute bottom-[-8vh] right-[-6vw] h-[38vw] w-[38vw] animate-drift2 rounded-full bg-[#c9a24a] opacity-30 blur-[90px]" />
            <i className="absolute left-[38vw] top-[-10vh] h-[30vw] w-[30vw] animate-drift3 rounded-full bg-kb opacity-25 blur-[90px]" />

        </div>

    )

}


export function Sidebar( { route } ) {

    const { data, navOpen, setNavOpen } = useApp()

    const b = data.bot

    return (

        <>

            <AnimatePresence>

                { navOpen && (

                    <motion.div
                        initial={ { opacity: 0 } }
                        animate={ { opacity: 1 } }
                        exit={ { opacity: 0 } }
                        className="fixed inset-0 z-50 bg-black/60 lg:hidden"
                        onClick={ () => setNavOpen( false ) }
                    />

                ) }

            </AnimatePresence>

            <aside
                aria-label="Navegación principal"
                className={ `glass fixed bottom-2.5 left-2.5 top-2.5 z-[60] flex w-[272px] flex-col p-3.5 transition-transform duration-500 lg:sticky lg:top-4 lg:z-10 lg:h-[calc(100vh-32px)] lg:translate-x-0 ${ navOpen ? 'translate-x-0' : '-translate-x-[120%]' }` }
            >

                <div className="flex items-center gap-3 px-2 pb-5 pt-1">

                    <div className="grid h-10 w-10 place-items-center rounded-[13px] bg-gradient-to-br from-kb to-kb-gold text-night-950 shadow-[0_8px_22px_-8px_rgb(var(--acc))]">

                        <Bot size={ 22 } />

                    </div>

                    <div>

                        <b className="block font-display text-[19px] font-extrabold leading-tight tracking-tight text-white">

                            KennyBot

                        </b>

                        <small className="text-xs text-white/50">Panel de control · V2</small>

                    </div>

                </div>

                <nav className="scrollless flex-1 overflow-y-auto">

                    { NAV.map( ( [ title, items ] ) => (

                        <div key={ title }>

                            <h6 className="mx-2.5 mb-1.5 mt-4 text-xs font-medium text-white/45">{ title }</h6>

                            { items.map( ( it ) => {

                                const active = route === it.id

                                return (

                                    <a
                                        key={ it.id }
                                        href={ `#/${ it.id }` }
                                        aria-current={ active ? 'page' : undefined }
                                        onClick={ () => setNavOpen( false ) }
                                        className="relative mb-0.5 flex items-center gap-[11px] rounded-xl px-[11px] py-[9px] font-medium text-white/80 no-underline transition hover:bg-white/[.07]"
                                    >

                                        { active && (

                                            <motion.span
                                                layoutId="navpill"
                                                transition={ { type: 'spring', stiffness: 380, damping: 32 } }
                                                className="absolute inset-0 rounded-xl bg-gradient-to-r from-kb/90 to-kb/50 shadow-[0_10px_24px_-12px_rgb(var(--acc))]"
                                            />

                                        ) }

                                        <it.icon
                                            size={ 18 }
                                            className={ `relative ${ active ? 'text-white' : 'opacity-75' }` }
                                        />

                                        <span className={ `relative ${ active ? 'text-white' : '' }` }>{ it.label }</span>

                                        { it.badge && (

                                            <span className="relative ml-auto rounded-full bg-white/15 px-2 text-[11.5px]">

                                                { it.badge( data ) }

                                            </span>

                                        ) }

                                    </a>

                                )

                            } ) }

                        </div>

                    ) ) }

                </nav>

                <div className="glass-sm mt-2.5 rounded-2xl bg-white/[.06] p-3.5">

                    <div className="flex items-center justify-between text-[13px]">

                        <span>Memoria</span>

                        <b>{ b.ramUsed } / { b.ramMax } MB</b>

                    </div>

                    <div className="bar mt-2.5">

                        <i style={ { width: b.ramUsed / b.ramMax * 100 + '%' } } />

                    </div>

                    <small className="mt-2 block text-xs text-white/50">

                        En línea: { uptimeText( b.uptimeSec ) }

                    </small>

                </div>

            </aside>

        </>

    )

}


export function Topbar() {

    const { setNavOpen, setPalette, data, toast } = useApp()

    return (

        <header className="glass glass-pill sticky top-2.5 z-20 mb-[18px] flex items-center gap-3 p-2.5 lg:top-4">

            <button
                aria-label="Abrir menú"
                onClick={ () => setNavOpen( true ) }
                className="grid h-[38px] w-[38px] flex-none place-items-center rounded-full bg-white/10 hover:bg-white/20 lg:hidden"
            >

                <Menu size={ 18 } />

            </button>

            <button
                onClick={ () => setPalette( true ) }
                className="flex h-[38px] min-w-0 flex-1 items-center gap-2.5 overflow-hidden whitespace-nowrap rounded-full bg-black/25 px-3.5 text-left text-white/50"
            >

                <Search size={ 16 } />

                <span className="truncate">Buscar páginas y acciones</span>

                <kbd className="ml-auto hidden rounded-md bg-white/10 px-[7px] font-mono text-[11.5px] sm:block">Ctrl K</kbd>

            </button>

            <div className="flex h-[38px] items-center gap-2 whitespace-nowrap rounded-full bg-kb/20 px-3.5 text-[13px] font-medium text-[#aef0d2]">

                <i className="h-2 w-2 animate-ping2 rounded-full bg-[#4dffb0]" />

                <span className="hidden sm:inline">Bot en línea</span>

            </div>

            <button
                aria-label="Notificaciones"
                onClick={ () => toast( `${ data.warns.length } warns activos y ningún error en la consola` ) }
                className="grid h-[38px] w-[38px] flex-none place-items-center rounded-full bg-white/10 hover:bg-white/20"
            >

                <Bell size={ 18 } />

            </button>

            <div className="grid h-[38px] w-[38px] flex-none place-items-center rounded-full bg-gradient-to-br from-kb-gold to-[#8a6a22] font-display font-extrabold text-[#1c1405]">

                K

            </div>

        </header>

    )

}


export function Toasts() {

    const { toasts } = useApp()

    return (

        <div
            className="fixed bottom-5 right-5 z-[100] grid gap-2.5"
            aria-live="polite"
        >

            <AnimatePresence>

                { toasts.map( ( t ) => (

                    <motion.div
                        key={ t.id }
                        layout
                        initial={ { opacity: 0, y: 16, scale: .95 } }
                        animate={ { opacity: 1, y: 0, scale: 1 } }
                        exit={ { opacity: 0, y: 10 } }
                        className={ `flex max-w-[360px] items-center gap-2.5 rounded-2xl px-4 py-3 shadow-2xl backdrop-blur-xl ${ t.kind === 'err' ? 'bg-[#5a1d12]/90' : 'bg-black/80' }` }
                    >

                        { t.kind === 'err'
                            ? <X size={ 18 } className="flex-none text-[#ff9d86]" />
                            : <Check size={ 18 } className="flex-none text-[#4dffb0]" /> }

                        <span>{ t.text }</span>

                    </motion.div>

                ) ) }

            </AnimatePresence>

        </div>

    )

}


export function Modal( { open, onClose, title, sub, children } ) {

    useEffect( () => {

        if ( ! open ) {

            return

        }

        const on = ( e ) => e.key === 'Escape' && onClose()

        window.addEventListener( 'keydown', on )

        return () => window.removeEventListener( 'keydown', on )

    }, [ open, onClose ] )

    return (

        <AnimatePresence>

            { open && (

                <motion.div
                    initial={ { opacity: 0 } }
                    animate={ { opacity: 1 } }
                    exit={ { opacity: 0 } }
                    className="fixed inset-0 z-[90] grid place-items-center bg-black/55 p-4 backdrop-blur-sm"
                    onMouseDown={ ( e ) => e.target === e.currentTarget && onClose() }
                >

                    <motion.div
                        role="dialog"
                        aria-modal="true"
                        aria-label={ title }
                        initial={ { opacity: 0, y: 24, scale: .96, filter: 'blur(8px)' } }
                        animate={ { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' } }
                        exit={ { opacity: 0, y: 12, scale: .98 } }
                        transition={ { type: 'spring', stiffness: 300, damping: 28 } }
                        className="glass glass-deep w-full max-w-[460px] p-6"
                    >

                        <div className="mb-5 flex items-start justify-between gap-3">

                            <div>

                                <h3 className="font-display text-[22px] font-extrabold tracking-tight text-white">{ title }</h3>

                                <p className="mt-0.5 text-[13px] text-white/55">{ sub }</p>

                            </div>

                            <button
                                aria-label="Cerrar"
                                onClick={ onClose }
                                className="grid h-8 w-8 place-items-center rounded-full bg-white/10 hover:bg-white/20"
                            >

                                <X size={ 16 } />

                            </button>

                        </div>

                        { children }

                    </motion.div>

                </motion.div>

            ) }

        </AnimatePresence>

    )

}


export function Palette() {

    const { palette, setPalette, toast, run } = useApp()

    const [ q, setQ ] = useState( '' )

    const ref = useRef( null )

    useEffect( () => {

        if ( palette ) {

            setQ( '' )

            setTimeout( () => ref.current?.focus(), 50 )

        }

    }, [ palette ] )

    const items = [

        ...NAV.flatMap( ( [ , list ] ) => list.map( ( i ) => ( { label: 'Ir a ' + i.label, icon: i.icon, go: () => { window.location.hash = '#/' + i.id } } ) ) ),

        {

            label: 'Recargar módulos',
            icon: LayoutDashboard,
            go: async () => { await run( '/reload', 'POST', undefined, 'Módulos recargados' ) },

        },

    ]

    const match = items.filter( ( i ) => i.label.toLowerCase().includes( q.trim().toLowerCase() ) )

    function pick( item ) {

        setPalette( false )

        item.go()

    }

    return (

        <Modal
            open={ palette }
            onClose={ () => setPalette( false ) }
            title="Buscar"
            sub="Salta a una página o ejecuta una acción"
        >

            <div className="field mb-3">

                <Search size={ 16 } className="text-white/50" />

                <input
                    ref={ ref }
                    value={ q }
                    onChange={ ( e ) => setQ( e.target.value ) }
                    onKeyDown={ ( e ) => e.key === 'Enter' && match[ 0 ] && pick( match[ 0 ] ) }
                    placeholder='Escribe "grupos" o "ajustes"…'
                    aria-label="Buscar"
                />

            </div>

            <ul className="m-0 max-h-[300px] list-none overflow-auto p-0">

                { match.length ? match.map( ( i ) => (

                    <li key={ i.label }>

                        <button
                            onClick={ () => pick( i ) }
                            className="flex w-full items-center gap-3 rounded-xl px-3.5 py-[11px] text-left hover:bg-white/10"
                        >

                            <i.icon size={ 17 } className="opacity-70" />

                            { i.label }

                        </button>

                    </li>

                ) ) : (

                    <li className="p-6 text-center text-white/50">

                        Nada coincide. Prueba con "grupos" o "ajustes".

                    </li>

                ) }

            </ul>

        </Modal>

    )

}
