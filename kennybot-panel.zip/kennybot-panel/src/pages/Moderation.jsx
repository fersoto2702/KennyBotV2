import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Bell, Plus, ShieldCheck, Users, Zap } from 'lucide-react'

import { CardHead, Glass, PageHead, Toggle } from '../components/Glass'
import { Modal } from '../components/Shell'
import { StatCard } from '../components/StatCard'
import { useApp } from '../state'
import { avatarBg } from '../lib/format'


const RULES = [

    [ 'Antienlaces', 'Borra enlaces de usuarios sin permiso (.antilink)', true ],
    [ 'Antibot', 'Expulsa otros bots que entren al grupo (.antibot)', true ],
    [ 'Antifake', 'Bloquea números de otros países al entrar (.antifake)', false ],
    [ 'Antispam', 'Bloquea ráfagas de mensajes repetidos', true ],
    [ 'Rate limiter', 'Máximo 6 comandos por minuto por usuario', true ],

]


export default function Moderation() {

    const { data, removeWarn, addWarn, toast, apiBase } = useApp()

    const live = !! apiBase

    const [ rules, setRules ] = useState( Object.fromEntries( RULES.map( ( [ t, , on ] ) => [ t, on ] ) ) )

    const [ open, setOpen ] = useState( false )

    const [ user, setUser ] = useState( '' )

    const [ group, setGroup ] = useState( data.groups[ 0 ]?.name || '' )

    const [ reason, setReason ] = useState( '' )


    async function submit( e ) {

        e.preventDefault()

        if ( await addWarn( user, group, reason ) ) {

            setOpen( false )
            setUser( '' )
            setReason( '' )

        }

    }


    return (

        <>

            <PageHead
                title="Moderación"
                sub="Warns activos y reglas automáticas. Al llegar al máximo de warns, el bot expulsa al usuario."
            >

                <button
                    className="btn btn-acc"
                    onClick={ () => setOpen( true ) }
                >

                    <Plus size={ 16 } />

                    Nuevo warn

                </button>

            </PageHead>


            <div className="grid grid-cols-12 gap-4">

                { ! live && <StatCard i={ 1 } icon={ ShieldCheck } label="Spam bloqueado hoy" value={ 318 } delta={ 21 } note="mensajes" seed={ 61 } /> }
                { ! live && <StatCard i={ 2 } icon={ Zap } label="Límites aplicados" value={ 74 } delta={ -9 } note="rate limiter" seed={ 62 } /> }
                { ! live && <StatCard i={ 3 } icon={ Users } label="Expulsiones (7 días)" value={ 12 } delta={ 3 } note="por warns" seed={ 63 } /> }

                <StatCard i={ 4 } icon={ Bell } label="Warns activos" value={ data.warns.length } delta={ 6 } note="pendientes" seed={ 64 } plain={ live } />


                <Glass
                    i={ 5 }
                    className="col-span-12 p-[22px] xl:col-span-7"
                >

                    <CardHead
                        title="Warns activos"
                        sub="Quita un warn si fue un error"
                    />

                    <div className="overflow-x-auto">

                        <table className="tbl min-w-[520px]">

                            <tbody>

                                <AnimatePresence initial={ false }>

                                    { data.warns.map( ( w ) => (

                                        <motion.tr
                                            key={ w.id }
                                            layout
                                            exit={ { opacity: 0, x: 30 } }
                                            transition={ { duration: .3 } }
                                        >

                                            <td>

                                                <div className="flex items-center gap-3">

                                                    <div
                                                        className="grid h-9 w-9 flex-none place-items-center rounded-xl font-display font-extrabold"
                                                        style={ { background: avatarBg( w.user ) } }
                                                    >

                                                        { w.user[ 0 ] }

                                                    </div>

                                                    <div>

                                                        <b className="block font-semibold leading-tight">{ w.user }</b>

                                                        <small className="text-white/45">{ w.group }</small>

                                                    </div>

                                                </div>

                                            </td>

                                            <td>{ w.reason }</td>

                                            <td>

                                                <span className={ `pill ${ w.count >= w.max ? 'pill-bad' : 'pill-warn' }` }>

                                                    { w.count } / { w.max }

                                                </span>

                                            </td>

                                            <td className="text-right">

                                                <button
                                                    className="btn btn-sm"
                                                    onClick={ () => removeWarn( w.id ) }
                                                >

                                                    Quitar warn

                                                </button>

                                            </td>

                                        </motion.tr>

                                    ) ) }

                                </AnimatePresence>

                            </tbody>

                        </table>

                    </div>

                    { ! data.warns.length && (

                        <div className="p-8 text-center text-white/50">

                            No hay warns activos. Cuando alguien rompa una regla, aparecerá aquí.

                        </div>

                    ) }

                </Glass>


                { ! live && (

                <Glass
                    i={ 6 }
                    className="col-span-12 p-[22px] xl:col-span-5"
                >

                    <CardHead
                        title="Reglas automáticas"
                        sub={ live ? 'Vista previa: estos interruptores todavía no se guardan en el bot' : 'Se aplican en todos los grupos' }
                    />

                    { RULES.map( ( [ t, d ] ) => (

                        <div
                            key={ t }
                            className="flex items-center justify-between gap-5 border-t border-white/[.07] py-3.5 first:border-0"
                        >

                            <div>

                                <b className="block font-semibold">{ t }</b>

                                <small className="text-white/45">{ d }</small>

                            </div>

                            <Toggle
                                on={ rules[ t ] }
                                label={ t }
                                onChange={ () => {

                                    setRules( ( r ) => ( { ...r, [ t ]: ! r[ t ] } ) )

                                    toast( `${ t } ${ rules[ t ] ? 'desactivado' : 'activado' }` )

                                } }
                            />

                        </div>

                    ) ) }

                </Glass>

                ) }

            </div>


            <Modal
                open={ open }
                onClose={ () => setOpen( false ) }
                title="Nuevo warn"
                sub="Cuando llegue a 3, el bot expulsa al usuario del grupo."
            >

                <form
                    onSubmit={ submit }
                    className="grid gap-3.5"
                >

                    <label className="grid gap-1.5 text-[13px] text-white/65">

                        Usuario

                        <div className="field">

                            <input
                                autoFocus
                                value={ user }
                                onChange={ ( e ) => setUser( e.target.value ) }
                                placeholder="Nombre o número"
                            />

                        </div>

                    </label>

                    <label className="grid gap-1.5 text-[13px] text-white/65">

                        Grupo

                        <div className="field">

                            <select
                                value={ group }
                                onChange={ ( e ) => setGroup( e.target.value ) }
                                className="w-full bg-transparent outline-none"
                            >

                                { data.groups.map( ( g ) => (

                                    <option
                                        key={ g.id }
                                        className="bg-night-900"
                                    >

                                        { g.name }

                                    </option>

                                ) ) }

                            </select>

                        </div>

                    </label>

                    <label className="grid gap-1.5 text-[13px] text-white/65">

                        Motivo

                        <div className="field">

                            <input
                                value={ reason }
                                onChange={ ( e ) => setReason( e.target.value ) }
                                placeholder="Enlaces repetidos"
                            />

                        </div>

                    </label>

                    <div className="mt-2 flex justify-end gap-2.5">

                        <button
                            type="button"
                            className="btn"
                            onClick={ () => setOpen( false ) }
                        >

                            Cancelar

                        </button>

                        <button
                            type="submit"
                            className="btn btn-acc"
                        >

                            Agregar warn

                        </button>

                    </div>

                </form>

            </Modal>

        </>

    )

}
