import { useState } from 'react'
import { motion } from 'framer-motion'
import { BarChart3, Check, Coins, Power, Users } from 'lucide-react'

import { Glass, PageHead, SampleNote, Seg } from '../components/Glass'
import { StatCard } from '../components/StatCard'
import { useApp } from '../state'


/*  Cambia aquí los precios y beneficios de tus planes  */

const PLANS = [

    {

        name: 'Gratis',
        price: 0,
        note: 'Para probar el bot',
        perks: [ 'Comandos básicos y stickers', 'Sistema de XP y niveles', 'Hasta 100 miembros por grupo', 'Soporte en la comunidad' ],

    },

    {

        name: 'Pro',
        price: 49,
        hot: true,
        note: 'Para grupos activos',
        perks: [ 'Todo lo de Gratis', 'Economía completa y tienda', 'Antienlaces y antispam', 'Descargas de TikTok y YouTube', 'Miembros ilimitados' ],

    },

    {

        name: 'Dedicado',
        price: 149,
        note: 'Tu propio bot con tu nombre',
        perks: [ 'Todo lo de Pro', 'Número de WhatsApp propio', 'Comandos a tu medida', 'Panel con tus datos', 'Soporte directo' ],

    },

]


export default function Plans() {

    const { toast, apiBase } = useApp()

    const [ billing, setBilling ] = useState( 'm' )


    return (

        <>

            <PageHead
                title="Planes"
                sub="Lo que ofreces a quienes quieren el bot en sus grupos. Los usuarios premium se agregan con .addpremium y se quitan con .delpremium."
            >

                <Seg
                    value={ billing }
                    onChange={ setBilling }
                    options={ [ [ 'm', 'Mensual' ], [ 'y', 'Anual · −20 %' ] ] }
                />

            </PageHead>


            { apiBase && (

                <SampleNote>

                    Los ingresos y suscriptores son de ejemplo: el bot no tiene un sistema de cobro conectado. Los planes sí los puedes editar en el código.

                </SampleNote>

            ) }


            <div className="grid grid-cols-12 gap-4">

                <StatCard i={ 1 } icon={ Coins } label="Ingresos del mes" value={ 4447 } delta={ 18 } note="MXN" seed={ 71 } pre="$" />
                <StatCard i={ 2 } icon={ Users } label="Grupos suscritos" value={ 191 } delta={ 7.5 } note="de pago" seed={ 72 } />
                <StatCard i={ 3 } icon={ BarChart3 } label="Ticket promedio" value={ 35 } delta={ 2.1 } note="MXN por grupo" seed={ 73 } pre="$" />
                <StatCard i={ 4 } icon={ Power } label="Cancelaciones" value={ 1 } delta={ -0.3 } note="este mes" seed={ 74 } suf=" %" />

            </div>


            <div className="mt-8 grid grid-cols-1 items-stretch gap-4 lg:grid-cols-3">

                { PLANS.map( ( p, i ) => {

                    const price = billing === 'y' ? Math.round( p.price * .8 ) : p.price

                    return (

                        <Glass
                            key={ p.name }
                            i={ i + 5 }
                            className={ `flex flex-col p-[26px] ${ p.hot ? 'lg:-translate-y-2.5 ring-1 ring-kb/50' : '' }` }
                            deep={ p.hot }
                        >

                            { p.hot && (

                                <span className="mb-3.5 self-start rounded-full bg-kb-gold px-[11px] py-[3px] text-[12.5px] font-semibold text-[#2a1d02]">

                                    El más elegido

                                </span>

                            ) }

                            <h4 className="font-display text-2xl font-extrabold tracking-tight text-white">{ p.name }</h4>

                            <small className="text-white/55">{ p.note }</small>

                            <div className="my-3.5 font-display text-5xl font-extrabold leading-none tracking-[-0.045em] text-white">

                                <motion.span
                                    key={ price }
                                    initial={ { opacity: 0, y: 8 } }
                                    animate={ { opacity: 1, y: 0 } }
                                    className="inline-block"
                                >

                                    ${ price }

                                </motion.span>

                                <small className="ml-1 font-sans text-sm font-normal tracking-normal text-white/55">MXN / mes</small>

                            </div>

                            <ul className="m-0 mb-6 mt-5 grid flex-1 list-none content-start gap-2.5 p-0">

                                { p.perks.map( ( x ) => (

                                    <li
                                        key={ x }
                                        className="flex items-start gap-2.5"
                                    >

                                        <Check size={ 17 } className="mt-0.5 flex-none text-kb" />

                                        <span>{ x }</span>

                                    </li>

                                ) ) }

                            </ul>

                            <button
                                className={ `btn justify-center ${ p.hot ? 'btn-acc' : '' }` }
                                onClick={ () => toast( `Plan ${ p.name } seleccionado. Conecta aquí tu pasarela de pago.` ) }
                            >

                                { p.price ? 'Elegir ' + p.name : 'Empezar gratis' }

                            </button>

                        </Glass>

                    )

                } ) }

            </div>

        </>

    )

}
