import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Coins, MessageSquare, Power, RefreshCw, Users, Zap } from 'lucide-react'

import { Bar, CardHead, Glass, PageHead, Seg } from '../components/Glass'
import { AreaChart, Gauge } from '../components/Charts'
import { CountUp, StatCard } from '../components/StatCard'
import { useApp } from '../state'
import { fmt, uptimeText } from '../lib/format'


const USERS = [ 'Valeria', 'Diego', 'Mariana', 'Fernando', 'Camila', 'Joaquín', 'Renata' ]

const pick = ( arr ) => arr[ Math.floor( Math.random() * arr.length ) ]


function makeLine( groups ) {

    const kinds = [

        () => [ 'INFO', `cmd .${ pick( [ 'daily', 'sticker', 'rank', 'tiktok', 'meme', 'balance' ] ) } ← ${ pick( USERS ) } (${ pick( groups ).name }) ${ 6 + Math.floor( Math.random() * 40 ) } ms` ],
        () => [ 'DB', `INSERT message_stats · grupo ${ pick( groups ).id } · ${ 1 + Math.floor( Math.random() * 4 ) } ms` ],
        () => [ 'SOCK', `cola de envío · ${ Math.floor( Math.random() * 6 ) } pendientes · ok` ],
        () => [ 'WARN', `antispam: ${ pick( USERS ) } excedió el límite en ${ pick( groups ).name }` ],
        () => [ 'INFO', `xp +${ 4 + Math.floor( Math.random() * 12 ) } → ${ pick( USERS ) }` ],

    ]

    const [ lvl, msg ] = pick( kinds )()

    return {

        id: Math.random(),
        time: new Date().toLocaleTimeString( 'es-MX', { hour12: false } ),
        lvl,
        msg,

    }

}


const LVL = {

    INFO: 'text-[#5fdca8]',
    WARN: 'text-[#e8c15b]',
    DB: 'text-[#7cc4ff]',
    SOCK: 'text-[#c9a0ff]',

}


function Terminal( { groups } ) {

    const [ lines, setLines ] = useState( () => Array.from( { length: 9 }, () => makeLine( groups ) ) )

    useEffect( () => {

        const id = setInterval( () => {

            setLines( ( l ) => [ ...l.slice( -13 ), makeLine( groups ) ] )

        }, 1500 )

        return () => clearInterval( id )

    }, [ groups ] )

    return (

        <div className="flex h-[292px] flex-col justify-end overflow-hidden font-mono text-[12.3px] leading-[1.75]">

            { lines.map( ( l ) => (

                <motion.div
                    key={ l.id }
                    initial={ { opacity: 0, x: -8 } }
                    animate={ { opacity: 1, x: 0 } }
                    className="truncate whitespace-nowrap"
                >

                    <span className="text-white/30">{ l.time }</span>
                    { ' ' }
                    <span className={ LVL[ l.lvl ] }>{ l.lvl.padEnd( 4 ) }</span>
                    { ' ' }
                    <span className="text-white/75">{ l.msg }</span>

                </motion.div>

            ) ) }

        </div>

    )

}


function Meter( { label, text, pct, delay } ) {

    return (

        <div className="mb-[15px] grid gap-[5px]">

            <div className="flex justify-between text-[13px]">

                <span>{ label }</span>

                <span className="tabular-nums text-white/50">{ text }</span>

            </div>

            <Bar
                pct={ pct }
                delay={ delay }
            />

        </div>

    )

}


export default function Overview() {

    const { data, run, apiBase } = useApp()

    const live = !! apiBase

    const available = Object.keys( data.ranges )

    const [ pickedRange, setRange ] = useState( '7d' )

    const range = available.includes( pickedRange ) ? pickedRange : available[ 0 ]

    const r = data.ranges[ range ]

    const series30 = data.ranges[ '30d' ]?.msgs || []

    const yesterday = series30[ series30.length - 2 ]
    const todayReal = series30[ series30.length - 1 ]

    const msgDelta = live && yesterday ? Math.round( ( todayReal - yesterday ) / yesterday * 1000 ) / 10 : 12.4

    const b = data.bot

    const total = data.groups.reduce( ( a, g ) => a + g.today, 0 )

    const hour = new Date().getHours()

    const hello = hour < 12 ? 'Buenos días' : hour < 19 ? 'Buenas tardes' : 'Buenas noches'


    return (

        <>

            <PageHead
                title={ `${ hello }, Kenny` }
                sub={ <>{ b.name } lleva <b className="text-white">{ uptimeText( b.uptimeSec ) }</b> en línea y procesó { fmt( total ) } mensajes hoy.</> }
            >

                <button
                    className="btn"
                    onClick={ () => run( '/reload', 'POST', undefined, ( r ) => r && r.total ? `Módulos recargados: ${ r.loaded } de ${ r.total }${ r.failed ? ' · ' + r.failed + ' con error' : '' }` : `Módulos recargados: ${ b.modules }` ) }
                >

                    <RefreshCw size={ 16 } />

                    Recargar módulos

                </button>

                <button
                    className="btn btn-acc"
                    onClick={ () => run( '/restart', 'POST', undefined, 'Reiniciando el bot… vuelve en unos segundos' ) }
                >

                    <Power size={ 16 } />

                    Reiniciar bot

                </button>

            </PageHead>


            <div className="grid grid-cols-12 gap-4">

                { r && (

                    <Glass
                        i={ 1 }
                        className={ `col-span-12 p-[22px] ${ live ? '' : 'xl:col-span-8' }` }
                    >

                        <CardHead
                            title="Actividad del bot"
                            sub={ r.cmds ? 'Mensajes recibidos y comandos ejecutados' : 'Mensajes recibidos por día' }
                        >

                            <Seg
                                value={ range }
                                onChange={ setRange }
                                options={ [ [ '24h', '24 h' ], [ '7d', '7 días' ], [ '30d', '30 días' ] ].filter( ( [ v ] ) => available.includes( v ) ) }
                            />

                        </CardHead>

                        <AreaChart
                            key={ range }
                            labels={ r.labels }
                            series={ [

                                { name: 'Mensajes', data: r.msgs, color: 'rgb(var(--acc))' },
                                r.cmds && { name: 'Comandos', data: r.cmds, color: '#d4a73c' },

                            ].filter( Boolean ) }
                        />

                        <div className="mt-2.5 flex flex-wrap gap-4 text-[13px] text-white/65">

                            <span><i className="mr-[7px] inline-block h-2.5 w-2.5 rounded-[3px] bg-kb" />Mensajes</span>

                            { r.cmds && <span><i className="mr-[7px] inline-block h-2.5 w-2.5 rounded-[3px] bg-kb-gold" />Comandos</span> }

                        </div>

                    </Glass>

                ) }


                { ! live && (


                <Glass
                    i={ 2 }
                    className="col-span-12 p-[22px] xl:col-span-4"
                >

                    <CardHead
                        title="Meta diaria de comandos"
                        sub="Objetivo: 2 000 comandos al día"
                    />

                    <Gauge pct={ 42 } />

                    <div className="mt-2 text-center font-display text-[34px] font-extrabold leading-none tracking-[-0.04em]">

                        <CountUp to={ 42 } suf="%" />

                    </div>

                    <div className="mt-[22px] grid grid-cols-3 gap-2 text-center">

                        { [ [ '842', 'hoy' ], [ '1 158', 'faltan' ], [ '18:00', 'pico' ] ].map( ( [ v, l ] ) => (

                            <div
                                key={ l }
                                className="rounded-[14px] bg-white/[.06] p-2.5"
                            >

                                <b className="block font-display text-[17px]">{ v }</b>

                                <span className="text-xs text-white/45">{ l }</span>

                            </div>

                        ) ) }

                    </div>

                </Glass>

                ) }


                <StatCard i={ 3 } icon={ MessageSquare } label="Mensajes hoy" value={ total } delta={ msgDelta } note="vs. ayer" seed={ 41 } plain={ live && ! yesterday } />

                { ! live && <StatCard i={ 4 } icon={ Zap } label="Comandos ejecutados" value={ 842 } delta={ 8.1 } note="vs. ayer" seed={ 42 } /> }

                <StatCard i={ 5 } icon={ Users } label="Grupos activos" value={ data.groups.filter( ( g ) => g.status !== 'muted' ).length } delta={ 4 } note={ `de ${ data.groups.length }` } seed={ 43 } plain={ live } />

                { ! live && <StatCard i={ 6 } icon={ Coins } label="Monedas en circulación" value={ 1284600 } delta={ -2.3 } note="economía" seed={ 44 } /> }


                { ! live && (

                <Glass
                    i={ 7 }
                    deep
                    className="col-span-12 p-[22px] xl:col-span-7"
                >

                    <CardHead
                        title="Consola en vivo"
                        sub="Eventos del socket, la base de datos y los comandos"
                    >

                        <span className="pill">en vivo</span>

                    </CardHead>

                    <Terminal groups={ data.groups } />

                </Glass>

                ) }


                <Glass
                    i={ 8 }
                    className={ `col-span-12 p-[22px] ${ live ? '' : 'xl:col-span-5' }` }
                >

                    <CardHead
                        title="Estado del sistema"
                        sub="Memoria, procesador, cola y latencias"
                    />

                    <Meter label="Memoria" text={ `${ b.ramUsed } / ${ b.ramMax } MB` } pct={ b.ramUsed / b.ramMax * 100 } delay={ 0 } />
                    <Meter label="CPU" text={ `${ b.cpu } %` } pct={ b.cpu } delay={ .08 } />
                    <Meter label="Cola de sockets" text={ `${ b.queue } / ${ b.queueMax }` } pct={ b.queue / b.queueMax * 100 } delay={ .16 } />
                    { b.wsPing > 0 && <Meter label="Latencia de WhatsApp" text={ `${ b.wsPing } ms` } pct={ b.wsPing / 2 } delay={ .24 } /> }
                    <Meter label="MySQL" text={ `${ b.dbPing } ms` } pct={ b.dbPing * 4 } delay={ .32 } />

                </Glass>

            </div>

        </>

    )

}
