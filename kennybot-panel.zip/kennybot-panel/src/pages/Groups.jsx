import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Eye, GripVertical, Users, VolumeX, Zap } from 'lucide-react'

import { Glass, PageHead, Toggle } from '../components/Glass'
import { useApp } from '../state'
import { avatarBg, fmt } from '../lib/format'


const COLUMNS = [

    { id: 'active', short: 'Activo', title: 'Activos', sub: 'El bot responde normal', icon: Zap, tone: 'text-[#7ff0bf]' },
    { id: 'watch', short: 'Vigilar', title: 'En observación', sub: 'Grupos a los que quieres prestar atención', icon: Eye, tone: 'text-[#f0cf7a]' },
    { id: 'muted', short: 'Silenciar', title: 'Silenciados', sub: 'El bot no responde', icon: VolumeX, tone: 'text-[#ff9b84]' },

]


const FEATURES = {

    antibot: 'Anti-bots',
    antifake: 'Anti-falsos',
    autolevelup: 'Nivel auto',

}


function shortId( id ) {

    const text = String( id ).split( '@' )[ 0 ]

    return text.length > 6 ? '…' + text.slice( -6 ) : 'ID ' + text.padStart( 3, '0' )

}


function GroupCard( { g, onDragStart, onDragEnd } ) {

    const { updateGroup, toast } = useApp()

    return (

        <motion.article
            layout
            layoutId={ 'g' + g.id }
            initial={ { opacity: 0, scale: .94 } }
            animate={ { opacity: 1, scale: 1 } }
            exit={ { opacity: 0, scale: .94 } }
            whileHover={ { y: -3 } }
            transition={ { type: 'spring', stiffness: 400, damping: 32 } }
            draggable
            onDragStart={ ( e ) => {

                e.dataTransfer.setData( 'text/plain', String( g.id ) )
                e.dataTransfer.effectAllowed = 'move'

                onDragStart( g.id )

            } }
            onDragEnd={ onDragEnd }
            className="cursor-grab rounded-[18px] bg-white/[.07] p-3.5 shadow-[inset_0_1px_0_rgba(255,255,255,.16)] active:cursor-grabbing"
        >

            <div className="flex items-center gap-3">

                <div
                    className="grid h-9 w-9 flex-none place-items-center rounded-xl font-display font-extrabold text-white"
                    style={ { background: avatarBg( g.name ) } }
                >

                    { g.name[ 0 ] }

                </div>

                <div className="min-w-0 flex-1">

                    <b className="block truncate font-semibold leading-tight">{ g.name }</b>

                    <small className="text-white/45">{ shortId( g.id ) }</small>

                </div>

                <GripVertical size={ 16 } className="flex-none text-white/30" />

            </div>

            <div className="mt-3 flex items-center justify-between text-[13px] text-white/60">

                <span className="inline-flex items-center gap-1.5">

                    <Users size={ 14 } />

                    { fmt( g.members ) }

                </span>

                <span className="tabular-nums">{ fmt( g.today ) } msgs hoy</span>

            </div>

            { Object.keys( g.features || {} ).length > 0 && (

                <div className="mt-3 grid grid-cols-2 gap-2 border-t border-white/[.08] pt-3 text-[12.5px]">

                    { Object.entries( g.features ).map( ( [ key, on ] ) => (

                        <label key={ key } className="flex items-center justify-between gap-2">

                            { FEATURES[ key ] || key }

                            <Toggle
                                on={ !! on }
                                label={ ( FEATURES[ key ] || key ) + ' en ' + g.name }
                                onChange={ () => {

                                    updateGroup( g.id, { features: { [ key ]: ! on } } )

                                    toast( `${ FEATURES[ key ] || key } ${ on ? 'desactivado' : 'activado' } en ${ g.name }` )

                                } }
                            />

                        </label>

                    ) ) }

                </div>

            ) }

            <div
                className="mt-3 flex gap-1.5"
                role="group"
                aria-label={ 'Mover ' + g.name }
            >

                { COLUMNS.map( ( c ) => (

                    <button
                        key={ c.id }
                        aria-pressed={ g.status === c.id }
                        onClick={ () => {

                            if ( g.status !== c.id ) {

                                updateGroup( g.id, { status: c.id } )

                                toast( `${ g.name } ahora está en "${ c.title }"` )

                            }

                        } }
                        className="chip h-7 flex-1 px-0 text-xs"
                    >

                        { c.short }

                    </button>

                ) ) }

            </div>

        </motion.article>

    )

}


export default function Groups() {

    const { data, updateGroup, toast } = useApp()

    const [ q, setQ ] = useState( '' )

    const [ dragging, setDragging ] = useState( null )

    const [ over, setOver ] = useState( null )

    const list = data.groups.filter( ( g ) => g.name.toLowerCase().includes( q.trim().toLowerCase() ) )


    function drop( e, status ) {

        e.preventDefault()

        const id = dragging ?? e.dataTransfer.getData( 'text/plain' )

        const g = data.groups.find( ( x ) => String( x.id ) === String( id ) )

        setOver( null )
        setDragging( null )

        if ( g && g.status !== status ) {

            updateGroup( g.id, { status } )

            toast( `${ g.name } ahora está en "${ COLUMNS.find( ( c ) => c.id === status ).title }"` )

        }

    }


    return (

        <>

            <PageHead
                title="Grupos"
                sub="Arrastra un grupo entre columnas para activarlo, vigilarlo o silenciarlo. También puedes usar los botones de cada tarjeta."
            >

                <div className="field w-[260px] max-w-full">

                    <input
                        value={ q }
                        onChange={ ( e ) => setQ( e.target.value ) }
                        placeholder="Buscar grupo…"
                        aria-label="Buscar grupo"
                    />

                </div>

            </PageHead>


            <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">

                { COLUMNS.map( ( col, ci ) => {

                    const items = list.filter( ( g ) => g.status === col.id )

                    return (

                        <Glass
                            key={ col.id }
                            i={ ci + 1 }
                            onDragOver={ ( e ) => {

                                e.preventDefault()

                                setOver( col.id )

                            } }
                            onDragLeave={ () => setOver( null ) }
                            onDrop={ ( e ) => drop( e, col.id ) }
                            className={ `p-4 transition-shadow ${ over === col.id ? 'shadow-[0_0_0_2px_rgb(var(--acc)),0_30px_60px_-32px_rgba(0,0,0,.85)]' : '' }` }
                        >

                            <div className="mb-3.5 flex items-center justify-between px-1">

                                <div className="flex items-center gap-2.5">

                                    <col.icon size={ 18 } className={ col.tone } />

                                    <div>

                                        <h3 className="font-display text-[17px] font-bold leading-tight text-white">{ col.title }</h3>

                                        <p className="text-xs text-white/45">{ col.sub }</p>

                                    </div>

                                </div>

                                <span className="pill">{ items.length }</span>

                            </div>

                            <div className="grid min-h-[120px] content-start gap-2.5">

                                <AnimatePresence>

                                    { items.map( ( g ) => (

                                        <GroupCard
                                            key={ g.id }
                                            g={ g }
                                            onDragStart={ setDragging }
                                            onDragEnd={ () => {

                                                setDragging( null )
                                                setOver( null )

                                            } }
                                        />

                                    ) ) }

                                </AnimatePresence>

                                { ! items.length && (

                                    <div className="grid place-items-center rounded-2xl border border-dashed border-white/15 p-6 text-center text-[13px] text-white/40">

                                        Suelta aquí un grupo para moverlo a "{ col.title }".

                                    </div>

                                ) }

                            </div>

                        </Glass>

                    )

                } ) }

            </div>

        </>

    )

}
