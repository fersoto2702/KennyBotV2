import { useState } from 'react'
import { motion } from 'framer-motion'
import { Plus } from 'lucide-react'

import { Bar, Glass, PageHead, Toggle } from '../components/Glass'
import { Modal } from '../components/Shell'
import { useApp } from '../state'
import { fmt } from '../lib/format'


export default function Commands() {

    const { data, toggleCommand, addCommand, apiBase } = useApp()

    const live = !! apiBase

    const cats = [ 'Todos', ...new Set( data.commands.map( ( c ) => c.cat ) ) ]

    const [ cat, setCat ] = useState( 'Todos' )

    const [ q, setQ ] = useState( '' )

    const [ open, setOpen ] = useState( false )

    const [ name, setName ] = useState( '' )

    const [ newCat, setNewCat ] = useState( 'Diversión' )

    const list = data.commands.filter( ( c ) => ( cat === 'Todos' || c.cat === cat ) && c.name.includes( q.trim().toLowerCase().replace( /^\./, '' ) ) )

    const active = data.commands.filter( ( c ) => c.on ).length


    async function create( e ) {

        e.preventDefault()

        if ( await addCommand( name, newCat ) ) {

            setOpen( false )
            setName( '' )

        }

    }


    return (

        <>

            <PageHead
                title="Comandos"
                sub={ live ? `${ data.commands.length } comandos cargados en el bot. Los cambios en archivos se aplican con «Recargar módulos».` : `${ active } de ${ data.commands.length } activos. Apaga uno y el bot deja de responderlo al instante, sin reiniciar.` }
            >

                <div className="field w-[220px] max-w-full">

                    <input
                        value={ q }
                        onChange={ ( e ) => setQ( e.target.value ) }
                        placeholder="Buscar comando…"
                        aria-label="Buscar comando"
                    />

                </div>

                <button
                    className="btn btn-acc"
                    onClick={ () => setOpen( true ) }
                >

                    <Plus size={ 16 } />

                    Nuevo comando

                </button>

            </PageHead>


            <div className="mb-4 flex flex-wrap gap-2">

                { cats.map( ( c ) => (

                    <button
                        key={ c }
                        className="chip"
                        aria-pressed={ cat === c }
                        onClick={ () => setCat( c ) }
                    >

                        { c }

                    </button>

                ) ) }

            </div>


            <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-3">

                { list.map( ( c, i ) => (

                    <motion.div
                        key={ c.name }
                        layout
                        initial={ { opacity: 0, y: 14, filter: 'blur(6px)' } }
                        animate={ { opacity: c.on ? 1 : .55, y: 0, filter: 'blur(0px)' } }
                        transition={ { delay: Math.min( i, 12 ) * .03, duration: .5 } }
                        whileHover={ { y: -3 } }
                        className="glass glass-sm flex flex-col gap-2.5 p-[15px]"
                    >

                        <div className="flex items-center justify-between gap-2.5">

                            <code className="font-mono text-[15px] font-medium">.{ c.name }</code>

                            { live ? (

                                <span className="pill">Cargado</span>

                            ) : (

                                <Toggle
                                    on={ c.on }
                                    label={ 'Activar .' + c.name }
                                    onChange={ () => toggleCommand( c.name ) }
                                />

                            ) }

                        </div>

                        <small className="text-white/45">{ c.cat } · { fmt( c.uses ) } usos</small>

                        <Bar pct={ Math.min( 100, c.uses / 70 ) } />

                    </motion.div>

                ) ) }

                { ! list.length && (

                    <div className="glass col-span-full p-8 text-center text-white/50">

                        No hay comandos con ese nombre en esta categoría.

                    </div>

                ) }

            </div>


            <Modal
                open={ open }
                onClose={ () => setOpen( false ) }
                title="Nuevo comando"
                sub="Se agrega activado. Escribe solo el nombre, sin el prefijo."
            >

                <form
                    onSubmit={ create }
                    className="grid gap-3.5"
                >

                    <label className="grid gap-1.5 text-[13px] text-white/65">

                        Nombre

                        <div className="field">

                            <span className="text-white/40">.</span>

                            <input
                                autoFocus
                                value={ name }
                                onChange={ ( e ) => setName( e.target.value ) }
                                placeholder="ruleta"
                            />

                        </div>

                    </label>

                    <div className="grid gap-1.5 text-[13px] text-white/65">

                        Categoría

                        <div className="flex flex-wrap gap-2">

                            { cats.slice( 1 ).map( ( c ) => (

                                <button
                                    type="button"
                                    key={ c }
                                    className="chip"
                                    aria-pressed={ newCat === c }
                                    onClick={ () => setNewCat( c ) }
                                >

                                    { c }

                                </button>

                            ) ) }

                        </div>

                    </div>

                    <div className="mt-2 flex justify-end gap-2.5">

                        <button
                            type="button"
                            className="btn"
                            onClick={ () => setOpen( false ) }
                        >

                            Cancelar

                        </button>

                        <button
                            type="submit"
                            className="btn btn-acc"
                        >

                            Crear comando

                        </button>

                    </div>

                </form>

            </Modal>

        </>

    )

}
