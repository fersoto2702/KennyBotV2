import { Bot, MessageSquare, Users, Zap } from 'lucide-react'

import { Bar, CardHead, Glass, PageHead, SampleNote } from '../components/Glass'
import { Donut, Heatmap } from '../components/Charts'
import { StatCard } from '../components/StatCard'
import { DAYS } from '../data/demo'
import { useApp } from '../state'
import { fmt } from '../lib/format'


const COLORS = [ 'rgb(var(--acc))', '#d4a73c', '#4fd8e6', '#8fd4b5', '#ff8a6b' ]


export default function Analytics() {

    const { data, toast, apiBase } = useApp()

    const top = [ ...data.commands ].sort( ( a, b ) => b.uses - a.uses ).slice( 0, 8 )

    const groups = [ ...data.groups ].sort( ( a, b ) => b.today - a.today ).slice( 0, 5 )


    function exportCsv() {

        const rows = [ 'comando,categoria,usos', ...data.commands.map( ( c ) => `${ c.name },${ c.cat },${ c.uses }` ) ]

        const blob = new Blob( [ rows.join( '\n' ) ], { type: 'text/csv' } )

        const a = document.createElement( 'a' )

        a.href = URL.createObjectURL( blob )
        a.download = 'kennybot-comandos.csv'

        a.click()

        toast( 'CSV exportado: kennybot-comandos.csv' )

    }


    return (

        <>

            <PageHead
                title="Analíticas"
                sub="Cuándo escriben, qué comandos usan y qué tipo de mensajes llegan."
            >

                <button
                    className="btn"
                    onClick={ exportCsv }
                >

                    Exportar CSV

                </button>

            </PageHead>


            { apiBase && (

                <SampleNote>

                    Esta página todavía usa datos de ejemplo: el bot no guarda horas, tipos de mensaje ni uso de comandos en MySQL. Solo "Grupos con más mensajes hoy" viene de tu bot.

                </SampleNote>

            ) }


            <div className="grid grid-cols-12 gap-4">

                <StatCard i={ 1 } icon={ MessageSquare } label="Mensajes (7 días)" value={ 48210 } delta={ 9.6 } note="semana actual" seed={ 51 } />
                <StatCard i={ 2 } icon={ Users } label="Usuarios únicos" value={ 2390 } delta={ 5.2 } note="esta semana" seed={ 52 } />
                <StatCard i={ 3 } icon={ Zap } label="Comandos (7 días)" value={ 9870 } delta={ 14.8 } note="semana actual" seed={ 53 } />
                <StatCard i={ 4 } icon={ Bot } label="Tasa de acierto" value={ 98 } delta={ -0.4 } note="sin errores" seed={ 54 } suf="%" />


                <Glass
                    i={ 5 }
                    className="col-span-12 p-[22px] xl:col-span-8"
                >

                    <CardHead
                        title="Mapa de actividad"
                        sub="Más brillante = más mensajes. Pasa el cursor sobre una celda."
                    />

                    <Heatmap days={ DAYS } />

                </Glass>


                <Glass
                    i={ 6 }
                    className="col-span-12 p-[22px] xl:col-span-4"
                >

                    <CardHead
                        title="Tipos de mensaje"
                        sub="Últimos 7 días"
                    />

                    <div className="grid grid-cols-1 items-center gap-5 sm:grid-cols-[150px_1fr] xl:grid-cols-1 2xl:grid-cols-[150px_1fr]">

                        <Donut
                            items={ data.types }
                            colors={ COLORS }
                            center="48,2 k"
                        />

                        <ul className="m-0 grid list-none gap-[9px] p-0 text-[13.5px]">

                            { data.types.map( ( t, i ) => (

                                <li
                                    key={ t.label }
                                    className="flex items-center justify-between gap-2.5"
                                >

                                    <span>

                                        <i
                                            className="mr-2 inline-block h-2.5 w-2.5 rounded-[3px]"
                                            style={ { background: COLORS[ i ] } }
                                        />

                                        { t.label }

                                    </span>

                                    <em className="not-italic text-white/45">{ t.value } %</em>

                                </li>

                            ) ) }

                        </ul>

                    </div>

                </Glass>


                <Glass
                    i={ 7 }
                    className="col-span-12 p-[22px] xl:col-span-6"
                >

                    <CardHead
                        title="Comandos más usados"
                        sub="Total acumulado de la semana"
                    />

                    { top.map( ( c, i ) => (

                        <div
                            key={ c.name }
                            className="mb-3 grid grid-cols-[82px_1fr_52px] items-center gap-3"
                        >

                            <code className="font-mono text-[13px]">.{ c.name }</code>

                            <Bar
                                pct={ c.uses / top[ 0 ].uses * 100 }
                                delay={ i * .05 }
                            />

                            <em className="text-right text-[13px] not-italic tabular-nums text-white/60">{ fmt( c.uses ) }</em>

                        </div>

                    ) ) }

                </Glass>


                <Glass
                    i={ 8 }
                    className="col-span-12 p-[22px] xl:col-span-6"
                >

                    <CardHead
                        title="Grupos con más mensajes hoy"
                        sub="Los cinco más activos"
                    />

                    { groups.map( ( g, i ) => (

                        <div
                            key={ g.id }
                            className="mb-3 grid grid-cols-[128px_1fr_52px] items-center gap-3"
                        >

                            <span className="truncate font-medium">{ g.name }</span>

                            <Bar
                                pct={ g.today / groups[ 0 ].today * 100 }
                                delay={ i * .05 }
                            />

                            <em className="text-right text-[13px] not-italic tabular-nums text-white/60">{ fmt( g.today ) }</em>

                        </div>

                    ) ) }

                </Glass>

            </div>

        </>

    )

}
