import { useState } from 'react'
import { motion } from 'framer-motion'

import { Bar, Glass, PageHead } from '../components/Glass'
import { useApp } from '../state'
import { avatarBg, fmt } from '../lib/format'


const LABEL = { xp: 'XP', coins: 'monedas', msgs: 'mensajes' }


function Avatar( { name, size = 36, className = '' } ) {

    return (

        <div
            className={ `grid flex-none place-items-center font-display font-extrabold text-white ${ className }` }
            style={ { width: size, height: size, background: avatarBg( name ), borderRadius: size * .32 } }
        >

            { name[ 0 ] }

        </div>

    )

}


export default function Ranking() {

    const { data } = useApp()

    const keys = Object.keys( LABEL ).filter( ( k ) => data.leaderboard.some( ( u ) => u[ k ] > 0 ) )

    const [ picked, setKey ] = useState( 'xp' )

    const key = keys.includes( picked ) ? picked : keys[ 0 ] || 'msgs'

    const sorted = [ ...data.leaderboard ].sort( ( a, b ) => b[ key ] - a[ key ] )

    const top = sorted[ 0 ]?.[ key ] || 1

    const podium = [ [ sorted[ 1 ], 2 ], [ sorted[ 0 ], 1 ], [ sorted[ 2 ], 3 ] ].filter( ( [ u ] ) => u )


    return (

        <>

            <PageHead
                title="Ranking"
                sub="Los usuarios con más nivel, monedas y mensajes en todos tus grupos."
            >

                { keys.map( ( k ) => (

                    <button
                        key={ k }
                        className="chip"
                        aria-pressed={ key === k }
                        onClick={ () => setKey( k ) }
                    >

                        { k === 'xp' ? 'XP' : k === 'coins' ? 'Monedas' : 'Mensajes' }

                    </button>

                ) ) }

            </PageHead>


            { ! sorted.length && (

                <Glass
                    i={ 1 }
                    className="p-10 text-center text-white/55"
                >

                    Todavía no hay usuarios con mensajes registrados. Cuando el bot guarde actividad en MySQL, aparecerán aquí.

                </Glass>

            ) }


            <div className="mb-4 grid grid-cols-1 items-end gap-3.5 md:grid-cols-[1fr_1.15fr_1fr]">

                { podium.map( ( [ u, n ], i ) => (

                    <Glass
                        key={ u.name }
                        i={ i + 1 }
                        className={ `p-[22px] text-center ${ n === 1 ? 'pb-10 md:order-none' : '' } ${ n === 3 ? 'pb-3' : '' }` }
                    >

                        <Avatar
                            name={ u.name }
                            size={ 62 }
                            className="mx-auto mb-2.5 text-2xl"
                        />

                        <b className="block font-display text-lg">{ u.name }</b>

                        <small className="text-white/45">Nivel { u.lvl } · puesto { n }</small>

                        <motion.div
                            key={ key }
                            initial={ { opacity: 0, y: 8 } }
                            animate={ { opacity: 1, y: 0 } }
                            className={ `mt-2 font-display text-[30px] font-extrabold tracking-[-0.03em] ${ n === 1 ? 'text-kb-gold' : '' }` }
                        >

                            { fmt( u[ key ] ) }

                        </motion.div>

                        <small className="text-white/45">{ LABEL[ key ] }</small>

                    </Glass>

                ) ) }

            </div>


            <Glass
                i={ 4 }
                className="p-[22px]"
            >

                { sorted.map( ( u, i ) => (

                    <motion.div
                        layout
                        key={ u.name }
                        transition={ { type: 'spring', stiffness: 300, damping: 30 } }
                        className="grid grid-cols-[28px_minmax(0,1fr)_70px] items-center gap-3.5 border-t border-white/[.07] px-1.5 py-[11px] first:border-0 sm:grid-cols-[34px_minmax(0,1.3fr)_minmax(0,1.6fr)_90px]"
                    >

                        <span className="font-display font-bold text-white/40">{ i + 1 }</span>

                        <div className="flex items-center gap-3">

                            <Avatar name={ u.name } />

                            <div>

                                <b className="block font-semibold leading-tight">{ u.name }</b>

                                <small className="text-white/45">Nivel { u.lvl }</small>

                            </div>

                        </div>

                        <div className="hidden sm:block">

                            <Bar
                                key={ key }
                                pct={ u[ key ] / top * 100 }
                                delay={ i * .04 }
                            />

                        </div>

                        <span className="text-right font-semibold tabular-nums">{ fmt( u[ key ] ) }</span>

                    </motion.div>

                ) ) }

            </Glass>

        </>

    )

}
