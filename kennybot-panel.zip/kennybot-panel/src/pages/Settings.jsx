import { useState } from 'react'

import { CardHead, Glass, PageHead, Toggle } from '../components/Glass'
import { ACCENTS, useApp } from '../state'
import { api } from '../lib/api'


const SYSTEM = [

    [ 'Hot reload', 'Recarga módulos al guardar archivos, sin reiniciar', true ],
    [ 'Subir de nivel automático', 'Avisa en el grupo cuando alguien sube de nivel (.autolevelup)', true ],
    [ 'Cola de sockets', 'Ordena los envíos para no saturar WhatsApp', true ],
    [ 'Estadísticas en MySQL', 'Guarda los mensajes en la base de datos', true ],
    [ 'Modo mantenimiento', 'El bot solo responde al dueño', false ],

]


export default function Settings() {

    const { apiBase, connect, disconnect, accent, setAccent, bg, setBg, toast } = useApp()

    const [ url, setUrl ] = useState( apiBase )

    const [ token, setToken ] = useState( api.token )

    const [ photo, setPhoto ] = useState( bg )

    const [ sys, setSys ] = useState( Object.fromEntries( SYSTEM.map( ( [ t, , on ] ) => [ t, on ] ) ) )


    return (

        <>

            <PageHead
                title="Ajustes"
                sub="Conexión con tu bot, apariencia y opciones del sistema."
            />


            <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">

                <Glass
                    i={ 1 }
                    className="p-[22px]"
                >

                    <CardHead
                        title="Conexión"
                        sub={ apiBase ? 'Conectado a ' + apiBase : 'Sin API: se muestran datos de ejemplo' }
                    />

                    <label className="grid gap-1.5 text-[13px] text-white/65">

                        URL de la API

                        <div className="field">

                            <input
                                value={ url }
                                onChange={ ( e ) => setUrl( e.target.value ) }
                                placeholder="https://tu-bot.com/api"
                            />

                        </div>

                    </label>

                    <label className="mt-3.5 grid gap-1.5 text-[13px] text-white/65">

                        Token (el PANEL_TOKEN de tu bot)

                        <div className="field">

                            <input
                                type="password"
                                autoComplete="off"
                                value={ token }
                                onChange={ ( e ) => setToken( e.target.value ) }
                                placeholder="Pega aquí tu token"
                            />

                        </div>

                    </label>

                    <div className="mt-3.5 flex flex-wrap gap-2.5">

                        <button
                            className="btn btn-acc"
                            onClick={ () => {

                                if ( ! url.trim() || ! token.trim() ) {

                                    toast( 'Escribe la URL y el token de tu API.', 'err' )

                                    return

                                }

                                connect( url.trim(), token.trim() )

                            } }
                        >

                            Conectar

                        </button>

                        <button
                            className="btn"
                            onClick={ () => {

                                setUrl( '' )
                                setToken( '' )

                                disconnect()

                            } }
                        >

                            Volver a datos de ejemplo

                        </button>

                    </div>

                    <div className="mt-5 flex items-center justify-between gap-5 border-t border-white/[.07] pt-4">

                        <div>

                            <b className="block font-semibold">Prefijo de comandos</b>

                            <small className="text-white/45">Lo que escriben antes del nombre</small>

                        </div>

                        <div className="field w-[84px]">

                            <input
                                defaultValue="."
                                maxLength={ 2 }
                                aria-label="Prefijo"
                            />

                        </div>

                    </div>

                </Glass>


                <Glass
                    i={ 2 }
                    className="p-[22px]"
                >

                    <CardHead
                        title="Apariencia"
                        sub="Se guarda en este navegador"
                    />

                    <div className="mb-1 text-[13px] text-white/65">Color de acento</div>

                    <div className="flex gap-2.5">

                        { ACCENTS.map( ( [ n, c ] ) => (

                            <button
                                key={ n }
                                title={ n }
                                aria-label={ n }
                                aria-pressed={ accent === c }
                                onClick={ () => {

                                    setAccent( c )

                                    toast( 'Color de acento actualizado' )

                                } }
                                className="h-[34px] w-[34px] rounded-full border-[3px] border-transparent transition hover:scale-110 aria-pressed:border-white"
                                style={ { background: `rgb(${ c })` } }
                            />

                        ) ) }

                    </div>

                    <label className="mt-5 grid gap-1.5 text-[13px] text-white/65">

                        Imagen de fondo (opcional)

                        <div className="field">

                            <input
                                value={ photo }
                                onChange={ ( e ) => setPhoto( e.target.value ) }
                                placeholder="https://… .jpg"
                            />

                        </div>

                    </label>

                    <div className="mt-3 flex gap-2.5">

                        <button
                            className="btn"
                            onClick={ () => {

                                setBg( photo.trim() )

                                toast( photo.trim() ? 'Fondo actualizado' : 'Fondo quitado' )

                            } }
                        >

                            Aplicar fondo

                        </button>

                        <button
                            className="btn"
                            onClick={ () => {

                                setPhoto( '' )
                                setBg( '' )

                            } }
                        >

                            Quitar

                        </button>

                    </div>

                </Glass>


                { ! apiBase && (

                <Glass
                    i={ 3 }
                    className="p-[22px] xl:col-span-2"
                >

                    <CardHead
                        title="Sistema"
                        sub="Opciones del núcleo del bot"
                    />

                    { SYSTEM.map( ( [ t, d ] ) => (

                        <div
                            key={ t }
                            className="flex items-center justify-between gap-5 border-t border-white/[.07] py-3.5 first:border-0"
                        >

                            <div>

                                <b className="block font-semibold">{ t }</b>

                                <small className="text-white/45">{ d }</small>

                            </div>

                            <Toggle
                                on={ sys[ t ] }
                                label={ t }
                                onChange={ () => {

                                    setSys( ( s ) => ( { ...s, [ t ]: ! s[ t ] } ) )

                                    toast( `${ t } ${ sys[ t ] ? 'desactivado' : 'activado' }` )

                                } }
                            />

                        </div>

                    ) ) }

                </Glass>

                ) }

            </div>

        </>

    )

}
