import { rng } from '../lib/format'
import { COMMANDS } from './commands'


export const DAYS = [ 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom' ]


export function makeSeries( n, base, amp, seed, shape ) {

    const r = rng( seed )

    return Array.from( { length: n }, ( _, i ) => {

        const wave = shape === 'day'
            ? Math.max( 0, Math.sin( ( i - 6 ) / 24 * Math.PI * 2 - 0.4 ) * .5 + .55 )
            : Math.sin( i / n * Math.PI * 3 ) * .35 + .65

        return Math.round( base + amp * wave + r() * amp * .3 )

    } )

}


export const DEMO = {

    bot: {

        name: 'KennyBot V2',
        online: true,
        uptimeSec: 12 * 86400 + 4 * 3600 + 18 * 60,
        ramUsed: 312,
        ramMax: 512,
        cpu: 14,
        queue: 3,
        queueMax: 20,
        wsPing: 38,
        dbPing: 4,
        modules: 48,

    },


    ranges: {

        '24h': {

            labels: Array.from( { length: 24 }, ( _, i ) => `${ i }h` ),
            msgs: makeSeries( 24, 120, 560, 11, 'day' ),
            cmds: makeSeries( 24, 20, 160, 12, 'day' ),

        },

        '7d': {

            labels: DAYS,
            msgs: makeSeries( 7, 4200, 5200, 21 ),
            cmds: makeSeries( 7, 700, 1500, 22 ),

        },

        '30d': {

            labels: Array.from( { length: 30 }, ( _, i ) => String( i + 1 ) ),
            msgs: makeSeries( 30, 3800, 5800, 31 ),
            cmds: makeSeries( 30, 600, 1700, 32 ),

        },

    },


    groups: [

        { id: 1, name: 'Los Cracks', members: 248, today: 1840, welcome: true, antilink: true, status: 'active' },
        { id: 2, name: 'Meme Zone', members: 512, today: 3120, welcome: true, antilink: false, status: 'watch' },
        { id: 3, name: 'Gamers Sonora', members: 187, today: 960, welcome: true, antilink: true, status: 'active' },
        { id: 4, name: 'Anime Night', members: 143, today: 702, welcome: false, antilink: true, status: 'active' },
        { id: 5, name: 'Estudio Pro', members: 96, today: 388, welcome: true, antilink: true, status: 'muted' },
        { id: 6, name: 'K-Pop Latam', members: 329, today: 1510, welcome: true, antilink: false, status: 'watch' },
        { id: 7, name: 'Música & Beats', members: 74, today: 241, welcome: false, antilink: false, status: 'active' },
        { id: 8, name: 'Dev Hermosillo', members: 61, today: 427, welcome: true, antilink: true, status: 'active' },
        { id: 9, name: 'Cine y Series', members: 205, today: 894, welcome: true, antilink: true, status: 'active' },
        { id: 10, name: 'Familia Bot', members: 28, today: 119, welcome: true, antilink: false, status: 'muted' },

    ].map( ( g ) => ( {

        ...g,

        features: { antibot: g.antilink, antifake: g.welcome, autolevelup: g.status !== 'muted' },

    } ) ),


    commands: COMMANDS,


    leaderboard: [

        { name: 'Valeria', lvl: 42, xp: 18420, coins: 92400, msgs: 12840 },
        { name: 'Diego', lvl: 39, xp: 16110, coins: 70120, msgs: 11020 },
        { name: 'Mariana', lvl: 37, xp: 14980, coins: 118300, msgs: 9870 },
        { name: 'Fernando', lvl: 34, xp: 12760, coins: 41800, msgs: 8420 },
        { name: 'Camila', lvl: 31, xp: 10940, coins: 56200, msgs: 7960 },
        { name: 'Joaquín', lvl: 29, xp: 9810, coins: 33700, msgs: 7110 },
        { name: 'Renata', lvl: 27, xp: 8650, coins: 64900, msgs: 6340 },
        { name: 'Emilio', lvl: 24, xp: 7120, coins: 22800, msgs: 5290 },
        { name: 'Ximena', lvl: 22, xp: 6240, coins: 38100, msgs: 4880 },
        { name: 'Santiago', lvl: 19, xp: 4980, coins: 15600, msgs: 3920 },

    ],


    warns: [

        { id: 1, user: 'Rodrigo', group: 'Meme Zone', reason: 'Enlaces repetidos', count: 2, max: 3 },
        { id: 2, user: 'Paola', group: 'Los Cracks', reason: 'Spam de stickers', count: 1, max: 3 },
        { id: 3, user: 'Iván', group: 'Gamers Sonora', reason: 'Lenguaje ofensivo', count: 3, max: 3 },
        { id: 4, user: 'Lucía', group: 'K-Pop Latam', reason: 'Flood de mensajes', count: 1, max: 3 },
        { id: 5, user: 'Mateo', group: 'Anime Night', reason: 'Enlaces repetidos', count: 2, max: 3 },

    ],


    types: [

        { label: 'Texto', value: 54 },
        { label: 'Stickers', value: 21 },
        { label: 'Imágenes', value: 13 },
        { label: 'Audios', value: 8 },
        { label: 'Video', value: 4 },

    ],

}
