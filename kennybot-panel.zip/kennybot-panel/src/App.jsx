import { AnimatePresence, motion } from 'framer-motion'

import { Background, Palette, Sidebar, Toasts, Topbar } from './components/Shell'
import { AppProvider, useHashRoute } from './state'

import Analytics from './pages/Analytics'
import Commands from './pages/Commands'
import Groups from './pages/Groups'
import Moderation from './pages/Moderation'
import Overview from './pages/Overview'
import Plans from './pages/Plans'
import Ranking from './pages/Ranking'
import Settings from './pages/Settings'


const PAGES = {

    overview: Overview,
    analytics: Analytics,
    groups: Groups,
    commands: Commands,
    ranking: Ranking,
    moderation: Moderation,
    plans: Plans,
    settings: Settings,

}


function Layout() {

    const route = useHashRoute()

    const Page = PAGES[ route ] || Overview

    return (

        <>

            <Background />

            <div className="relative z-[1] grid min-h-screen grid-cols-1 gap-4 p-2.5 sm:p-4 lg:grid-cols-[272px_minmax(0,1fr)]">

                <Sidebar route={ route } />

                <div className="min-w-0">

                    <Topbar />

                    <AnimatePresence mode="wait">

                        <motion.main
                            key={ route }
                            exit={ { opacity: 0, y: -10, filter: 'blur(8px)' } }
                            transition={ { duration: .22 } }
                        >

                            <Page />

                        </motion.main>

                    </AnimatePresence>

                </div>

            </div>

            <Palette />

            <Toasts />

        </>

    )

}


export default function App() {

    return (

        <AppProvider>

            <Layout />

        </AppProvider>

    )

}
